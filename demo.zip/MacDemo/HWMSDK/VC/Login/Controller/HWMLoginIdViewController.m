//
//  HWMLoginIdViewController.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMLoginIdViewController.h"
#import "HWMInputInfoTitleCell.h"
#import "HWMLoginInputInfoModel.h"
#import <HWMUISDK/HWMUISDK.h>
#import "HWMAppIdLoginModel.h"
#import <CommonCrypto/CommonCrypto.h>
#import "HWMAppKeyManager.h"
#import "HWMTableView.h"

@interface HWMLoginIdViewController ()<HWMTableViewDataSourse, HWMTableViewDelegate, HWMInputInfoTitleCellDelegate>
/// tableView
@property (nonatomic, strong) HWMTableView *listView;
/// 按钮
@property (nonatomic, strong) NSButton *loginBtn;
/// 数据源
@property (nonatomic, strong) NSMutableArray *dataArr;
/// model
@property (nonatomic, strong) HWMAppIdLoginModel *loginParam;

@end

@implementation HWMLoginIdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
}

- (void)viewWillAppear {
    [super viewWillAppear];
    [self setupData];
}

#pragma mark - Data
- (void)setupData {
    if (self.dataArr.count > 0) {
        return;
    }
    NSString *appID = [HWMAppKeyManager shareInstance].appId;
    NSString *appKey = [HWMAppKeyManager shareInstance].appKey;
    NSString *noce = [self randomStringOfCount:32];
    NSArray *data = @[@{ @"title": @"APPID:", @"place": @"请输入APPID（必填）", @"content":
                         appID},
                      @{ @"title": @"APPKEY:", @"place": @"请输入APPKEY（必填）", @"content": appKey},
                      @{ @"title": @"过期时间:", @"place": @"请输入过期时间（必填）", @"content": @"0" },
                      @{ @"title": @"随机数:", @"place": @"请输入随机数（32~64位）（必填）", @"content": noce },
                      @{ @"title": @"账号:", @"place": @"请输入账号（必填）", @"content": @"" },
                      @{ @"title": @"昵称:", @"place": @"请输入昵称（必填）", @"content": @"" },
                      @{ @"title": @"手机号:", @"place": @"请输入手机号（选填）", @"content": @"" },
                      @{ @"title": @"邮箱:", @"place": @"请输入邮箱（选填）", @"content": @"" },
                      @{ @"title": @"corpId:", @"place": @"请输入corpId（选填）", @"content": @"" }];

    for (NSDictionary *dic in data) {
        HWMLoginInputInfoModel *model = [[HWMLoginInputInfoModel alloc] init];
        model.title = dic[@"title"];
        model.placeholder = dic[@"place"];
        model.content = dic[@"content"];
        [self.dataArr addObject:model];
    }

    self.loginParam = [[HWMAppIdLoginModel alloc] init];
    self.loginParam.appId = appID;
    self.loginParam.appKey = appKey;
    self.loginParam.expireTime = 0;
    self.loginParam.nonce = noce;
    [self.listView reloadData];
}

#pragma mark - UI
- (void)setupUI {
    
    self.listView = [[HWMTableView alloc] initTableViewClomuIdentifier:@"loginIDView"];
    self.listView.delegate = self;
    self.listView.dataSource = self;
    [self.view addSubview:self.listView];
    [self.listView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.equalTo(self.view).offset(15);
        make.right.equalTo(self.view).offset(-15);
        make.bottom.equalTo(self.view).offset(-100);
    }];

    [self.view addSubview:self.loginBtn];
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-20);
        make.height.mas_equalTo(35);
        make.width.mas_equalTo(250);
    }];
}

#pragma mark - Delegate

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return self.dataArr.count;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    HWMInputInfoTitleCell *cell = [tableView makeViewWithIdentifier:NSStringFromClass([HWMInputInfoTitleCell class]) owner:self];
    if (!cell) {
        cell = [[HWMInputInfoTitleCell alloc] initWithFrame:NSMakeRect(0, 0, 200, 50)];
        cell.identifier = NSStringFromClass([HWMInputInfoTitleCell class]);
    }
    cell.index = row;
    cell.model = self.dataArr[row];
    cell.delegate = self;
    return cell;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 50.0;
}

- (void)inputInfoCellDidEdite:(NSString *)content index:(NSInteger)index {
    if (index == 0) {
        self.loginParam.appId = content;
        if (content.length > 0) {
            [HWMAppKeyManager shareInstance].appId = content;
        }
    } else if (index == 1) {
        self.loginParam.appKey = content;
        if (content.length > 0) {
            [HWMAppKeyManager shareInstance].appKey = content;
        }
    } else if (index == 2) {
        if (content.length > 0) {
            if ([self isAllNumber:content]) {
                self.loginParam.expireTime = content.integerValue > 0 ? content.integerValue : -1;
            }
        } else {
            self.loginParam.expireTime = -1;
        }
    } else if (index == 3) {
        self.loginParam.nonce = content;
    } else if (index == 4) {
        self.loginParam.thirdUserId = content;
    } else if (index == 5) {
        self.loginParam.userName = content;
    } else if (index == 6) {
        self.loginParam.userPhone = content;
    } else if (index == 7) {
        self.loginParam.userEmail = content;
    } else if (index == 8) {
        self.loginParam.corpId = content;
    }
}

#pragma mark - Event
- (void)login {
    
    if (![HWMSdk hasInit]) {
        [HWMConsoleManager shareInstance].console = @"no init";
        return;
    }

    if (self.loginParam.appId.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入APPID";
        return;
    }

    if (self.loginParam.appKey.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入APPKEY";
        return;
    }

    if (self.loginParam.expireTime < 0) {
        [HWMConsoleManager shareInstance].console = @"请输入过期时间";
        return;
    }

    if (self.loginParam.nonce.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入随机数";
        return;
    }

    if (self.loginParam.thirdUserId.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入账号";
        return;
    }

    if (self.loginParam.userName.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入昵称";
        return;
    }
    
    HWMAppIDLoginParam *loginModel = [self convertFromLoginModel:self.loginParam];
    [[HWMSdk getOpenApi] login:loginModel callback:^(NSError *_Nullable error, HWMLoginResult *_Nullable result) {
        if (error) {
            [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%@", error.description];
        } else {
            [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"login successful. corpId = %@  uuid = %@", result.corpId, result.uuid];
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"login"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
    }];
}


- (HWMAppIDLoginParam *)convertFromLoginModel:(HWMAppIdLoginModel*)model
{
    HWMAppIDLoginParam *appidModel = [HWMAppIDLoginParam new];
    appidModel.signature = [self createSignature];
    appidModel.thirdUserId = model.thirdUserId;
    appidModel.expireTime = model.expireTime;
    appidModel.nonce = model.nonce;
    appidModel.userName = model.userName;
    appidModel.userEmail = model.userEmail;
    appidModel.userPhone = model.userPhone;
    appidModel.corpId = model.corpId;
    
    return appidModel;
}
/// 生成随机数
- (NSString *)randomStringOfCount:(NSUInteger)count {
    static NSString *_string = @"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    NSMutableString *nonce = [NSMutableString stringWithCapacity:count];
    for (NSUInteger i = 0; i < count; i++) {
        NSUInteger random = arc4random() % _string.length;
        [nonce appendFormat:@"%c", [_string characterAtIndex:random]];
    }
    return [nonce copy];
}

- (NSString *)createSignature
{
    NSString *inputStr;
    if (self.loginParam.corpId.length > 0) {
        inputStr = [NSString stringWithFormat:@"%@:%@:%@:%lu:%@", self.loginParam.appId, self.loginParam.corpId, self.loginParam.thirdUserId, (unsigned long)self.loginParam.expireTime, self.loginParam.nonce];
    } else {
        inputStr = [NSString stringWithFormat:@"%@:%@:%lu:%@", self.loginParam.appId, self.loginParam.thirdUserId, (unsigned long)self.loginParam.expireTime, self.loginParam.nonce];
    }
    return  [self hmacSHA256WithSecret:self.loginParam.appKey content:inputStr];
}

- (NSString *)hmacSHA256WithSecret:(NSString *)secret content:(NSString *)content
{
    const char *cKey = [secret cStringUsingEncoding:NSASCIIStringEncoding];
    const char *cData = [content cStringUsingEncoding:NSUTF8StringEncoding];// 有可能有中文 所以用NSUTF8StringEncoding -> NSASCIIStringEncoding
    unsigned char cHMAC[CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    NSData *HMACData = [NSData dataWithBytes:cHMAC length:sizeof(cHMAC)];
    const unsigned char *buffer = (const unsigned char *)[HMACData bytes];
    NSMutableString *HMAC = [NSMutableString stringWithCapacity:HMACData.length * 2];
    for (int i = 0; i < HMACData.length; ++i) {
        [HMAC appendFormat:@"%02x", buffer[i]];
    }

    return HMAC;
}

- (BOOL)isAllNumber:(NSString *)str {
    NSString *regex = @"[0-9]*";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [pred evaluateWithObject:str];
}

#pragma mark - Login
- (NSButton *)loginBtn {
    if (!_loginBtn) {
        _loginBtn = [NSButton buttonWithTitle:@"登录" font:nil fontColor:[NSColor whiteColor] target:self action:@selector(login)];
        _loginBtn.layer.backgroundColor = [NSColor colorWithRGB:0x0D94FF].CGColor;
        _loginBtn.layer.cornerRadius = 4.0;
        _loginBtn.layer.masksToBounds = YES;
    }
    return _loginBtn;
}

- (NSMutableArray *)dataArr {
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

@end
