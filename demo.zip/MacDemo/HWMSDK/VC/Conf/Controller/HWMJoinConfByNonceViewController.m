//
//  HWMJoinConfByNonceViewController.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/6/11.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMJoinConfByNonceViewController.h"
#import "HWMInputInfoTitleCell.h"
#import <CommonCrypto/CommonCrypto.h>
#import "HWMAppKeyManager.h"
#import "HWMTableView.h"
#import "HWMLoginInputInfoModel.h"
#import "HWMSwitchCell.h"

#define HTTP_URL @"https://api.meeting.huaweicloud.com/"

@interface HWMJoinConfByNonceViewController ()<HWMTableViewDataSourse, HWMTableViewDelegate, HWMInputInfoTitleCellDelegate, HWMSwitchCellDelegate>
/// tableView
@property (nonatomic, strong) HWMTableView *listView;
/// 按钮
@property (nonatomic, strong) NSButton *joinBtn;
/// 数据源
@property (nonatomic, strong) NSMutableArray *dataArr;
///
@property (nonatomic, assign) BOOL isCamOn;
@property (nonatomic, assign) BOOL isMicOn;
@property (nonatomic, copy) NSString *nickName;
@property (nonatomic, copy) NSString *userID;
@property (nonatomic, copy) NSString *confId;
@property (nonatomic, copy) NSString *password;
@property (nonatomic, copy) NSString *nonce;
@property (nonatomic, copy) NSString *corpId;
@property (nonatomic, copy) NSString *signature;
@property (nonatomic, assign) BOOL useInvalidNonce;

@end

@implementation HWMJoinConfByNonceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
}

- (void)viewWillAppear {
    [super viewWillAppear];
    [self setupData];
}

#pragma mark - Data
- (void)setupData {
    //self.corpId = @"188503804";
    if (self.dataArr.count > 0) {
        return;
    }
    NSArray *data = @[
        @{ @"title": @"会议ID:", @"place": @"请输入会议ID（必填）", @"content": @"" },
        @{ @"title": @"会议密码", @"place": @"请输入密码（选填）", @"content": @"" },
        @{ @"title": @"昵称:", @"place": @"请输入昵称（必填）", @"content": @"" },
        @{ @"title": @"用户ID:", @"place": @"请输入用户ID（必填）", @"content": @"" },
        @{ @"title": @"麦克风:", @"place": @"", @"content": @"" },
        @{ @"title": @"摄像头:", @"place": @"", @"content": @"" },
        @{ @"title": @"是否使用无效nonce:", @"place": @"", @"content": @"" },];

    for (NSDictionary *dic in data) {
        HWMLoginInputInfoModel *model = [[HWMLoginInputInfoModel alloc] init];
        model.title = dic[@"title"];
        model.placeholder = dic[@"place"];
        model.content = dic[@"content"];
        [self.dataArr addObject:model];
    }
    self.password = @"";
    [self.listView reloadData];
}

#pragma mark - UI
- (void)setupUI {
    self.listView = [[HWMTableView alloc] initTableViewClomuIdentifier:@"loginIDView"];
    self.listView.delegate = self;
    self.listView.dataSource = self;
    [self.view addSubview:self.listView];
    [self.listView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.equalTo(self.view).offset(15);
        make.right.equalTo(self.view).offset(-15);
        make.bottom.equalTo(self.view).offset(-100);
    }];

    [self.view addSubview:self.joinBtn];
    [self.joinBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-20);
        make.height.mas_equalTo(35);
        make.width.mas_equalTo(250);
    }];
}

#pragma mark - Delegate

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return self.dataArr.count;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    HWMLoginInputInfoModel *model = self.dataArr[row];

    if (row < 4) {
        HWMInputInfoTitleCell *cell = [tableView makeViewWithIdentifier:NSStringFromClass([HWMInputInfoTitleCell class]) owner:self];
        if (!cell) {
            cell = [[HWMInputInfoTitleCell alloc] initWithFrame:NSMakeRect(0, 0, 200, 50)];
            cell.identifier = NSStringFromClass([HWMInputInfoTitleCell class]);
        }
        cell.index = row;
        cell.model = model;
        cell.delegate = self;
        return cell;
    }

    HWMSwitchCell *cell = [HWMSwitchCell initSwitchCell:tableView ower:self];
    cell.index = row;
    cell.delegate = self;
    cell.title = model.title;
    if (row == 4) {
        cell.state = self.isMicOn;
    } else if (row == 5){
        cell.state = self.isCamOn;
    }else {
        cell.state = self.useInvalidNonce;
    }
    return cell;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 50.0;
}

- (void)inputInfoCellDidEdite:(NSString *)content index:(NSInteger)index {
    HWMLoginInputInfoModel *model = self.dataArr[index];
    model.content = content;
    if (index == 0) {
        self.confId = content;
    } else if (index == 1) {
        self.password = content;
    } else if (index == 2){
        self.nickName = content;
    }else {
        self.userID = content;
    }
}

- (void)switchStateChanged:(BOOL)state index:(NSInteger)index {
    if (index == 4) {
        self.isMicOn = state;
    } else if (index == 5){
        self.isCamOn = state;
    }else {
        self.useInvalidNonce = state;
    }
}

#pragma mark - Event
- (void)joinConf {
    if (self.confId.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入会议ID";
        return;
    }

    if (self.nickName.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入会议昵称";
        return;
    }

    [self appAuth];
}

#pragma mark - HTTP

- (void)appAuth {
    AFHTTPSessionManager *manager = [self manager];
    self.signature = [self createSignature];
    NSString *auth = [NSString stringWithFormat:@"HMAC-SHA256 signature=%@", self.signature];
    [manager.requestSerializer setValue:auth forHTTPHeaderField:@"Authorization"];

    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"appId"] = [HWMAppKeyManager shareInstance].appId;
    params[@"expireTime"] = @(0);
    params[@"nonce"] = self.nonce;
    params[@"userName"] = self.nickName;
    params[@"userId"] = self.userID;
    params[@"clientType"] = @(72);
    params[@"corpId"] = self.corpId;

    NSString *url = [NSString stringWithFormat:@"%@%@", HTTP_URL, @"v2/usg/acs/auth/appauth"];

    [manager POST:url parameters:params headers:nil progress:^(NSProgress *_Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask *_Nonnull task, id _Nullable responseObject) {
        NSDictionary *jsonDict = [self getJsonFromResponse:responseObject];
        if ([jsonDict isKindOfClass:[NSDictionary class]] && [jsonDict.allKeys containsObject:@"accessToken"]) {
            NSString *token = jsonDict[@"accessToken"];
            [self getNonceWithToken:token];
        } else {
            [HWMConsoleManager shareInstance].console = @"获取 token 失败";
        }
    } failure:^(NSURLSessionDataTask *_Nullable task, NSError *_Nonnull error) {
        [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"nonce error : %@", error.description];
    }];
}

- (void)getNonceWithToken:(NSString *)token {
    AFHTTPSessionManager *manager = [self manager];
    [manager.requestSerializer setValue:token forHTTPHeaderField:@"X-Access-Token"];

    NSString *url = [NSString stringWithFormat:@"%@%@", HTTP_URL, @"v1/usg/acs/auth/portal-ref-nonce"];

    [manager POST:url parameters:nil headers:nil progress:^(NSProgress *_Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask *_Nonnull task, id _Nullable responseObject) {
        NSDictionary *jsonDict = [self getJsonFromResponse:responseObject];
        if ([jsonDict isKindOfClass:[NSDictionary class]] && [jsonDict.allKeys containsObject:@"nonce"]) {
            NSString *nonce = jsonDict[@"nonce"];
            NSString *baseUrl = @"cloudlink://welinksoftclient/h5page?page=LoginAndJoinConf&server_url=bmeeting.huaweicloud.com&port=8443&";

            NSString *openMic = self.isMicOn ? @"ture" : @"false";
            NSString *openCma = self.isCamOn ? @"ture" : @"false";
            if (self.useInvalidNonce) {
                nonce = @"ajajahahgsgsgwtwywywywygaaggaaa";
            }
            NSString *url = [NSString stringWithFormat:@"%@&conf_id=%@&enter_code=%@&name=%@&open_mic=%@&open_camera=%@&signature=%@&appid=%@&userid=%@&nonce=%@&expiretime=0", baseUrl, self.confId, self.password, self.nickName, openMic, openCma, self.signature, [HWMAppKeyManager shareInstance].appId, self.userID, nonce];
            BOOL isOpen = [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:url]];
            if (isOpen) {
                [HWMConsoleManager shareInstance].console = @"已打开华为云会议";
            }else {
                [HWMConsoleManager shareInstance].console = @"没有安装华为云会议";
            }
        } else {
            [HWMConsoleManager shareInstance].console = @"获取 nonce 失败";
        }
    } failure:^(NSURLSessionDataTask *_Nullable task, NSError *_Nonnull error) {
        [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"nonce error : %@", error.description];
    }];
}

- (AFHTTPSessionManager *)manager {
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    AFHTTPRequestSerializer *serializer = [AFJSONRequestSerializer serializer];
    serializer.timeoutInterval = 20;
    [serializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    manager.requestSerializer = serializer;
    AFHTTPResponseSerializer *responseSerializer = [AFHTTPResponseSerializer serializer];
    responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", @"text/plain", @"image/png", @"image/jpeg", nil];
    manager.responseSerializer = responseSerializer;
    return manager;
}

/// 生成随机数
- (NSString *)randomStringOfCount:(NSUInteger)count {
    static NSString *_string = @"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    NSMutableString *nonce = [NSMutableString stringWithCapacity:count];
    for (NSUInteger i = 0; i < count; i++) {
        NSUInteger random = arc4random() % _string.length;
        [nonce appendFormat:@"%c", [_string characterAtIndex:random]];
    }
    return [nonce copy];
}

- (NSString *)createSignature {
    NSString *appID = [HWMAppKeyManager shareInstance].appId;
    NSString *appKey = [HWMAppKeyManager shareInstance].appKey;
    NSString *inputStr;
    self.nonce = [self randomStringOfCount:64];
    if (self.corpId.length > 0) {
        inputStr = [NSString stringWithFormat:@"%@:%@:%@:%lu:%@", appID, self.corpId, self.userID, (unsigned long)0, self.nonce];
    } else {
        inputStr = [NSString stringWithFormat:@"%@:%@:%lu:%@", appID, self.userID, (unsigned long)0, self.nonce];
    }

    return [self hmacSHA256WithSecret:appKey content:inputStr];
}

- (NSString *)hmacSHA256WithSecret:(NSString *)secret content:(NSString *)content {
    const char *cKey = [secret cStringUsingEncoding:NSASCIIStringEncoding];
    const char *cData = [content cStringUsingEncoding:NSUTF8StringEncoding];// 有可能有中文 所以用NSUTF8StringEncoding -> NSASCIIStringEncoding
    unsigned char cHMAC[CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    NSData *HMACData = [NSData dataWithBytes:cHMAC length:sizeof(cHMAC)];
    const unsigned char *buffer = (const unsigned char *)[HMACData bytes];
    NSMutableString *HMAC = [NSMutableString stringWithCapacity:HMACData.length * 2];
    for (int i = 0; i < HMACData.length; ++i) {
        [HMAC appendFormat:@"%02x", buffer[i]];
    }

    return HMAC;
}

- (NSDictionary *)getJsonFromResponse:(id)responseObj {
    NSData *data = (NSData *)responseObj;
    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
    return jsonDict;
}

#pragma mark - Login
- (NSButton *)joinBtn {
    if (!_joinBtn) {
        _joinBtn = [NSButton buttonWithTitle:@"加入会议" font:nil fontColor:[NSColor whiteColor] target:self action:@selector(joinConf)];
        _joinBtn.layer.backgroundColor = [NSColor colorWithRGB:0x0D94FF].CGColor;
        _joinBtn.layer.cornerRadius = 4.0;
        _joinBtn.layer.masksToBounds = YES;
    }
    return _joinBtn;
}

- (NSMutableArray *)dataArr {
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

@end
