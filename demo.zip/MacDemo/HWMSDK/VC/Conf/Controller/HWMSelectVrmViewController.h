//
//  HWMSelectVrmViewController.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/6.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN
@class HWMVmrInfoModel;
typedef void(^SelectVrmInfoHandler)(HWMVmrInfoModel *infoModel);
@interface HWMSelectVrmViewController : HWMBaseViewController

/// 数据
@property (nonatomic, strong) NSArray<HWMVmrInfoModel *> *vmrArr;
/// 回调
@property (nonatomic, copy) SelectVrmInfoHandler selectVrmInfoHandler;

@end

NS_ASSUME_NONNULL_END
