//
//  HWMTableView.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/11.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@protocol HWMTableViewDelegate <NSTableViewDelegate>

@end

@protocol HWMTableViewDataSourse <NSTableViewDataSource>

@end

@interface HWMTableView : NSView

- (instancetype)initTableViewClomuIdentifier:(NSString *)identifier;

/// 列表
@property (nonatomic, strong) NSTableView *listView;
/// 滚动视图
@property (nonatomic, strong) NSScrollView *scrollView;

/// delegate
@property (nonatomic, weak) id<HWMTableViewDelegate> delegate;
/// datasource
@property (nonatomic, weak) id<HWMTableViewDataSourse> dataSource;

- (void)reloadData;

@end

NS_ASSUME_NONNULL_END
