//
//  HWMConfDetailCell.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/2.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "HWMConfDetailItemModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface HWMConfDetailCell : NSTableCellView

+ (instancetype)confDetailCell:(NSTableView *)tableView ower:(id)ower;

/// model
@property (nonatomic, strong) HWMConfDetailItemModel *model;

@end

NS_ASSUME_NONNULL_END
