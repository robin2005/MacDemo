//
//  HWMBookConfViewController.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/28.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBookConfViewController.h"
#import <HWMUISDK/HWMUISDK.h>
#import "HWMInputInfoTitleCell.h"
#import "HWMConfTypeSelectCell.h"
#import "HWMSwitchCell.h"
#import "HWMJoinConfLimitCell.h"
#import "NSViewController+HWMNavigation.h"
#import "HWMSelectContactViewController.h"
#import "HWMTableView.h"
#import "HWMContactInfoModel.h"

@interface HWMBookConfViewController ()<HWMTableViewDataSourse, HWMTableViewDelegate, HWMInputInfoTitleCellDelegate, HWMSwitchCellDelegate>
/// tableView
@property (nonatomic, strong) HWMTableView *listView;
/// Vmr
@property (nonatomic, copy) NSArray<HWMVmrInfoModel *> *vmrList;
/// 会议参数model
@property (nonatomic, strong) HWMOrderConfParam *confParam;
/// 确定按钮
@property (nonatomic, strong) NSButton *confirmBtn;
/// 是否使用个人ID
@property (nonatomic, assign) BOOL usePersonalID;
/// 是否携带与会者
@property (nonatomic, assign) BOOL addAttentee;
/// 是否自动外呼
@property (nonatomic, assign) BOOL isAutoInvite;
/// 与会者
@property (nonatomic, strong) NSMutableArray <HWMAttendeeInfo *> *attenteeArr;
@end

@implementation HWMBookConfViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
}

- (void)viewWillAppear {
    [super viewWillAppear];
    [self getVmrList];
    [self resetAttendee];
}

#pragma mark - Data
- (void)getVmrList {
    if (![HWMSdk hasInit]) {
        return;
    }
    @weakify(self)
    [[HWMBizSdk getBizOpenApi] getVmrList:^(NSError *_Nullable error, NSArray<HWMVmrInfoModel *> *_Nullable result) {
        @strongify(self)
        if (error) {
            [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%@", error.description];
        } else {
            self.vmrList = result;
            [self.listView reloadData];
        }
    }];
}

- (void)setDetailModel:(HWMConfDetail *)detailModel {
    _detailModel = detailModel;
    [self.attenteeArr addObjectsFromArray:self.detailModel.attendee];
    self.confParam.confId = self.detailModel.confId;
    self.confParam.confSubject = self.detailModel.confSubject;
    self.confParam.isSmsOn = self.detailModel.sendSms;
    self.confParam.isMailOn = self.detailModel.sendEmailNotify;
    self.confParam.isEmailCalenderOn = self.detailModel.sendCalendarNotify;
    self.confParam.startTime = self.detailModel.startTime;
    self.confParam.callInRestrictionType = self.detailModel.callInRestriction;
    self.confParam.isAutoRecord = self.detailModel.isAutoRecord;
    self.confParam.vmrId = self.detailModel.vmrId;
    self.confParam.duration = (self.detailModel.endTime - self.detailModel.startTime) / 60;
    self.usePersonalID = self.detailModel.vmrFlag;
    self.confParam.attendee = self.attenteeArr;
    self.confParam.guestPwd = self.detailModel.generalPwd;
    self.confParam.noPassword = self.detailModel.guestFreePwd;
    self.addAttentee = self.attenteeArr.count > 1 ? YES : NO;
    
    [self.listView reloadData];
}

- (void)resetAttendee {
    if (self.detailModel) {
        return;
    }
    self.addAttentee = NO;
    [self.attenteeArr removeAllObjects];
    [self.listView reloadData];
}

#pragma mark - UI
- (void)setupUI {
    
    self.listView = [[HWMTableView alloc] initTableViewClomuIdentifier:@"bookConf"];
    self.listView.delegate = self;
    self.listView.dataSource = self;
    [self.view addSubview:self.listView];

    NSString *title = self.detailModel ? @"编辑会议" : @"预约会议";
    self.confirmBtn = [NSButton buttonWithTitle:title font:nil fontColor:[NSColor whiteColor] target:self action:@selector(confirmBtnClick)];
    self.confirmBtn.layer.backgroundColor = [NSColor colorWithRGB:0x0D94FF].CGColor;
    self.confirmBtn.layer.cornerRadius = 4.0;
    self.confirmBtn.layer.masksToBounds = YES;
    [self.view addSubview:self.confirmBtn];

    [self.confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-20);
        make.height.mas_equalTo(35);
        make.width.mas_equalTo(250);
    }];

    [self.listView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.equalTo(self.view).offset(15);
        make.right.equalTo(self.view).offset(-15);
        make.bottom.equalTo(self.confirmBtn.mas_top).offset(-15);
    }];
}

/// 可输入cell
- (HWMInputInfoTitleCell *)inputInfoCell:(NSTableView *)tableView row:(NSInteger)row {
    HWMInputInfoTitleCell *cell = [HWMInputInfoTitleCell inputInfoTitleCell:tableView ower:self];
    cell.delegate = self;
    cell.index = row;
    if (row == 0) {
        cell.title = @"会议主题";
        cell.placeholder = @"请输入会议主题";
        cell.content = self.confParam.confSubject;
        cell.enabled = YES;
    } else if (row == 1) {
        cell.title = @"开始时间";
        cell.placeholder = @"格式：yyyy-MM-dd HH:mm";
        cell.content = [NSString getLocalTimeZoneTimeWithTimeInterval:self.confParam.startTime formart:@"yyyy-MM-dd HH:mm"];
        cell.enabled = YES;
    } else if (row == 2) {
        cell.title = @"会议时长";
        cell.placeholder = @"请输入会议时长(单位：分钟)";
        if (self.confParam.duration > 0) {
            cell.content = [NSString stringWithFormat:@"%lu", self.confParam.duration];
        }
        cell.enabled = YES;
    } else if (row == 12) {
        cell.title = @"来宾密码";
        cell.placeholder = @"不填使用随机密码";
        cell.enabled = !self.confParam.noPassword && !self.usePersonalID;
        cell.content = self.confParam.guestPwd;
    }
    return cell;
}

/// switch cell
- (HWMSwitchCell *)switchCell:(NSTableView *)tableView row:(NSInteger)row {
    HWMSwitchCell *cell = [HWMSwitchCell initSwitchCell:tableView ower:self];
    cell.index = row;
    cell.delegate = self;
    if (row == 3) {
        HWMVmrInfoModel *model = self.vmrList.firstObject;
        cell.title = [NSString stringWithFormat:@"使用个人会议ID %@", model.confId.length > 0 ? model.confId : @""];
        cell.state = self.usePersonalID;
        if(self.detailModel) {
            cell.enabled = NO;
        }
        HWMInputInfoTitleCell *pwdTextCell = [self.listView.listView viewAtColumn:0 row:12 makeIfNecessary:YES];
        HWMSwitchCell *pwdCell = [self.listView.listView viewAtColumn:0 row:10 makeIfNecessary:YES];
        if(pwdCell) {
            pwdCell.enabled = !self.usePersonalID;
        }
        if(pwdTextCell) {
            pwdTextCell.enabled = !self.usePersonalID && !self.confParam.noPassword;
        }
    } else if (row == 4) {
        cell.title = @"是否携带与会者";
        cell.state = self.addAttentee;
        cell.enabled = YES;
    } else if (row == 6) {
        cell.title = @"打开会议录制";
        cell.state = self.confParam.isAutoRecord;
        cell.enabled = YES;
    } else if (row == 7) {
        cell.title = @"邮件通知";
        cell.state = self.confParam.isMailOn;
        cell.enabled = YES;
    } else if (row == 8) {
        cell.title = @"短信通知";
        cell.state = self.confParam.isSmsOn;
        cell.enabled = YES;
    } else if (row == 9) {
        cell.title = @"日历邮件通知";
        cell.state = self.confParam.isEmailCalenderOn;
        cell.enabled = YES;
    } else if (row == 10) {
        cell.title = @"是否设置来宾密码";
        cell.state = !self.confParam.noPassword;
        cell.enabled = !self.usePersonalID;
    } else if (row == 11) {
        cell.title = @"会议开始自动呼叫与会者";
        cell.state = self.isAutoInvite;
        cell.enabled = YES;
    }
    return cell;
}

#pragma mark - Delegate
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return 13;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    if (row < 3 || row == 12) {
        return [self inputInfoCell:tableView row:row];
    } else if (row == 5) {
        HWMJoinConfLimitCell *cell = [HWMJoinConfLimitCell joinConfLimitCell:tableView ower:self];
        cell.type = self.confParam.callInRestrictionType;
        @weakify(self)
        [cell setJoinConfLimitSelectHandler:^(NSInteger type) {
            @strongify(self)
            self.confParam.callInRestrictionType = type;
        }];
        return cell;
    }
    return [self switchCell:tableView row:row];
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 40.0;
}

- (void)inputInfoCellDidEdite:(NSString *)content index:(NSInteger)index {
    if (index == 0) {
        self.confParam.confSubject = content;
    } else if (index == 1) {
        if (!isnan([NSString getTimeIntervalWithDateString:content])) {
            self.confParam.startTime = [NSString getTimeIntervalWithDateString:content];
        }else {
            self.confParam.startTime = 0;
        }
    } else if (index == 2){
        self.confParam.duration = content.integerValue;
    } else if (index == 12) {
        self.confParam.guestPwd = content;
    }
}

- (void)switchStateChanged:(BOOL)state index:(NSInteger)index {
    switch (index) {
        case 3:
        {
            self.usePersonalID = state;
            HWMInputInfoTitleCell *pwdTextCell = [self.listView.listView viewAtColumn:0 row:12 makeIfNecessary:YES];
            HWMSwitchCell *pwdCell = [self.listView.listView viewAtColumn:0 row:10 makeIfNecessary:YES];
            pwdCell.enabled = !self.usePersonalID;
            pwdTextCell.enabled = !self.usePersonalID && !self.confParam.noPassword;
        }
            break;
        case 4:{
            if (!state) {
                self.addAttentee = NO;
                [self.attenteeArr removeAllObjects];
                return;
            }
            HWMSwitchCell *cell = [self.listView.listView viewAtColumn:0 row:index makeIfNecessary:YES];
            cell.state = NO;
            HWMSelectContactViewController *contact = [[HWMSelectContactViewController alloc] init];
            @weakify(self)
            [contact setSelectAttendeeInfoHandler:^(NSArray *_Nullable attendees) {
                @strongify(self)
                for (HWMContactInfoModel *model in attendees) {
                    HWMAttendeeInfo *info = [[HWMAttendeeInfo alloc] init];
                    info.accountId = model.accountId;
                    info.name = model.name;
                    info.number = model.number;
                    info.thirdUserId = model.thirdUserId;
                    info.email = model.email;
                    info.mute = model.mute;
                    info.role = model.role;
                    info.sms = model.sms;
                    info.isAutoInvite = self.isAutoInvite;
                    [self.attenteeArr addObject:info];
                }
                if (attendees.count > 0) {
                    self.addAttentee = YES;
                    cell.state = YES;
                } else {
                    self.addAttentee = NO;
                }
            }];
            [self presentViewControllerAsModalWindow:contact];
        }
            break;
        case 6:
            self.confParam.isAutoRecord = state;
            break;
        case 7:
            self.confParam.isMailOn = state;
            break;
        case 8:
            self.confParam.isSmsOn = state;
            break;
        case 9:
            self.confParam.isEmailCalenderOn = state;
            break;
        case 10:
        {
            self.confParam.noPassword = !state;
            HWMInputInfoTitleCell *pwdCell = [self.listView.listView viewAtColumn:0 row:12 makeIfNecessary:YES];
            if(pwdCell && [pwdCell isKindOfClass:[HWMInputInfoTitleCell class]]) {
                pwdCell.enabled = state && !self.usePersonalID;
            }
        }
            break;
        case 11:
        {
            self.isAutoInvite = state;
            for (HWMAttendeeInfo *info in self.attenteeArr) {
                info.isAutoInvite = self.isAutoInvite;
            }
        }
            break;
        default:
            break;
    }
}

#pragma mark - Event
- (void)confirmBtnClick {
    if (self.detailModel) {
        [self editeConf];
    } else {
        [self orderConf];
    }
}

- (void)orderConf {
    if (![HWMSdk hasInit]) {
        [HWMConsoleManager shareInstance].console = @"no init";
        return;
    }

    if (self.confParam.confSubject.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入会议主题";
        return;
    }

    if (self.confParam.startTime <= 0) {
        [HWMConsoleManager shareInstance].console = @"请输入开始时间";
        return;
    }

    if (self.confParam.duration <= 0) {
        [HWMConsoleManager shareInstance].console = @"请输入时长";
        return;
    }
    self.confParam.attendee = self.attenteeArr;
    
    if (self.usePersonalID) {
        self.confParam.vmrId = self.vmrList.firstObject.vmrId;
    }else {
        self.confParam.vmrId = @"";
    }
    [[HWMBizSdk getBizOpenApi] bookConf:self.confParam callback:^(NSError *_Nullable error, id _Nullable result) {
        if (error) {
            [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%@", error.description];
        } else {
            if (result && [result isKindOfClass:[HWMConfDetail class]]) {
                HWMConfDetail *confdetail = (HWMConfDetail *)result;
                NSString *confId = confdetail.vmrConferenceId.length > 0 ? confdetail.vmrConferenceId : confdetail.confId;
                [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"order conf succeeded. confid is %@, confSubject = %@", confId, confdetail.confSubject];
            }
        }
    }];
}

- (void)editeConf {
    if (![HWMSdk hasInit]) {
        [HWMConsoleManager shareInstance].console = @"no init";
        return;
    }

    if (self.confParam.confSubject.length == 0) {
        [HWMConsoleManager shareInstance].console = @"请输入会议主题";
        return;
    }

    if (self.confParam.startTime <= 0) {
        [HWMConsoleManager shareInstance].console = @"请输入开始时间";
        return;
    }

    if (self.confParam.duration <= 0) {
        [HWMConsoleManager shareInstance].console = @"请输入时长";
        return;
    }
    @weakify(self)
    [[HWMBizSdk getBizOpenApi] editConf:self.confParam callback:^(NSError * _Nullable error, id  _Nullable result) {
        @strongify(self)
        if (error) {
            [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%@", error.description];
        } else {
            [HWMConsoleManager shareInstance].console = @"edit conf succeeded";
            if (self.editConfSuccessHandler) {
                self.editConfSuccessHandler();
            }
            [self.customNavigationController popViewControllerAnimated:YES];
        }
    }];
}

#pragma mark - Lazy

- (HWMOrderConfParam *)confParam {
    if (!_confParam) {
        _confParam = [[HWMOrderConfParam alloc] init];
    }
    return _confParam;
}

- (NSMutableArray<HWMAttendeeInfo *> *)attenteeArr {
    if (!_attenteeArr) {
        _attenteeArr = [NSMutableArray array];
    }
    return _attenteeArr;
}

@end
