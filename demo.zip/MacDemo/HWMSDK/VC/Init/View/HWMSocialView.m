//
//  HWMSocialView.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/13.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMSocialView.h"
#import "HWMTableView.h"
#import "HWMConfDetailCell.h"
#import "HWMConfDetailItemModel.h"

@interface HWMSocialView ()<HWMTableViewDelegate, HWMTableViewDataSourse>

/// tableView
@property (nonatomic, strong) HWMTableView *tableView;
/// 会议数据
@property (nonatomic, strong) NSMutableArray <HWMConfDetailItemModel *> *dataArr;

@end

@implementation HWMSocialView

- (instancetype)initWithFrame:(NSRect)frameRect {
    if (self = [super initWithFrame:frameRect]) {
        [self setupUI];
    }
    return self;
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
}

#pragma mark - UI
- (void)setupUI {
    self.wantsLayer = YES;
    self.layer.backgroundColor = [NSColor whiteColor].CGColor;
    
    self.tableView = [[HWMTableView alloc] initTableViewClomuIdentifier:@"social"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self addSubview:self.tableView];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.equalTo(self).offset(10);
        make.right.and.bottom.equalTo(self).offset(-10);
    }];
}

- (void)setConfDetail:(HWMConfStateInfo *)confDetail {
    [self.dataArr removeAllObjects];
    _confDetail = confDetail;
    if (confDetail.confSubject.length > 0) {
        HWMConfDetailItemModel *subModel = [[HWMConfDetailItemModel alloc] init];
        subModel.title = @"会议主题";
        subModel.content = confDetail.confSubject;
        [self.dataArr addObject:subModel];
    }
    
    if (confDetail.startTime > 0 && confDetail.endTime > 0) {
        HWMConfDetailItemModel *timeModel = [[HWMConfDetailItemModel alloc] init];
        timeModel.title = @"会议时间";
        
        NSString *startTime = [NSString timeStringFromTimeInterval:confDetail.startTime];
        NSString *endTime = [NSString timeStringFromTimeInterval:confDetail.endTime];
        timeModel.content = [NSString stringWithFormat:@"%@ - %@", startTime, endTime];
        [self.dataArr addObject:timeModel];
    }

    if (confDetail.confId.length > 0 || confDetail.vmrConferenceId.length > 0) {
        HWMConfDetailItemModel *idModel = [[HWMConfDetailItemModel alloc] init];
        idModel.title = @"会议ID";
        idModel.content = confDetail.vmrConferenceId.length > 0 ? confDetail.vmrConferenceId : confDetail.confId;
        [self.dataArr addObject:idModel];
    }
   
    if (confDetail.chairmanPwd.length > 0 && confDetail.role == HWMConfRoleTypeChairman) {
        HWMConfDetailItemModel *hostModel = [[HWMConfDetailItemModel alloc] init];
        hostModel.title = @"主持人密码";
        hostModel.content = confDetail.chairmanPwd;
        [self.dataArr addObject:hostModel];
    }
    
    if (confDetail.generalPwd.length > 0) {
        HWMConfDetailItemModel *guestModel = [[HWMConfDetailItemModel alloc] init];
        guestModel.title = @"来宾密码";
        guestModel.content = confDetail.generalPwd;
        [self.dataArr addObject:guestModel];
    }
   
    HWMConfDetailItemModel *typeModel = [[HWMConfDetailItemModel alloc] init];
    typeModel.title = @"会议类型";
    typeModel.content = confDetail.videoConf ? @"视频会议" : @"音频会议";
    [self.dataArr addObject:typeModel];

    HWMConfDetailItemModel *orderModel = [[HWMConfDetailItemModel alloc] init];
    orderModel.title = @"会议预订人";
    orderModel.content = confDetail.confScheduledName.length > 0 ? confDetail.confScheduledName : @"-";
    [self.dataArr addObject:orderModel];

//    HWMConfDetailItemModel *recordModel = [[HWMConfDetailItemModel alloc] init];
//    recordModel.title = @"自动录制会议";
//    recordModel.content = confDetail.isAutoRecord ? @"是" : @"否";
//    [self.dataArr addObject:recordModel];
    
    [self.tableView reloadData];
}

#pragma mark - Delegate
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return self.dataArr.count;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    HWMConfDetailCell *cell = [HWMConfDetailCell confDetailCell:tableView ower:self];
    cell.model = self.dataArr[row];
    return cell;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 45.0;
}

- (NSMutableArray<HWMConfDetailItemModel *> *)dataArr {
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}


@end
