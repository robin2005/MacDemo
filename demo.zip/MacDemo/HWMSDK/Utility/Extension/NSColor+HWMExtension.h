//
//  NSColor+HWMExtension.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSColor (HWMExtension)

+ (NSColor *)colorWithRGB:(uint32_t)rgbValue;
+ (NSColor *)colorWithRGB:(uint32_t)rgbValue alpha:(CGFloat)alpha;
+ (NSColor *)colorWithRGBA:(uint32_t)rgbaValue;
+ (NSColor *)colorWithR:(float)r g:(float)g b:(float)b;
+ (NSColor *)randomColor;

@end

NS_ASSUME_NONNULL_END
