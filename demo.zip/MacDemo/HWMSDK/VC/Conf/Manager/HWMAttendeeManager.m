//
//  HWMAttendeeManager.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/8/24.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMAttendeeManager.h"

@implementation HWMAttendeeManager

+ (void)logAttendees:(NSArray <HWMAttendeeInfo *> *)attendees {
    NSMutableString *itemsString = [[NSMutableString alloc] init];
    [attendees enumerateObjectsUsingBlock:^(HWMAttendeeInfo * _Nonnull attendeeInfo, NSUInteger idx, BOOL * _Nonnull stop) {
        [itemsString appendFormat:@"第%zd个与会者\n昵称：%@\n账号：%@\n三方账号：%@\n会议状态:%@\norgid：%@\n是否匿名：%@\n会议中角色：%@\nnumber：%@\n,", idx, attendeeInfo.name,attendeeInfo.accountId, attendeeInfo.thirdUserId, [self getStateStr:attendeeInfo.state], attendeeInfo.orgId, attendeeInfo.isAnonymous? @"是":@"否",[self getRoleStr:attendeeInfo.role],attendeeInfo.number];
    }];
    [HWMConsoleManager shareInstance].console = itemsString;
}

+ (NSString *)getStateStr:(HWMAttendeeState)state {
    switch (state) {
        case HWMAttendeeStateInConf:
            return @"会议中";
        case HWMAttendeeStateCalling:
            return @"正在呼叫";
        case HWMAttendeeStateJoining:
            return @"正在加入会议";
        case HWMAttendeeStateLeaved:
            return @"已经离开";
        case HWMAttendeeStateNoExist:
            return @"用户不存在";
        case HWMAttendeeStateBusy:
            return @"被叫用户忙";
        case HWMAttendeeStateNoAnswer:
            return @"用户无应答";
        case HWMAttendeeStateReject:
            return @"用户拒绝接听";
        case HWMAttendeeStateFailed:
            return @"呼叫失败";
        default:
            return @"未知";
    }
}

+ (NSString *)getRoleStr:(HWMConfRoleType)type {
    switch (type) {
        case HWMConfRoleTypeAttendee:
            return @"与会者";
        case HWMConfRoleTypeChairman:
            return @"主席";
        case HWMConfRoleTypeAudience:
            return @"观众";
        case HWMConfRoleTypeCohost:
            return @"联席主席";
        default:
            return @"";
    }
}


@end
