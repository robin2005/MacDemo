//
//  HWMLoginInputInfoModel.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/27.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMLoginInputInfoModel.h"

@implementation HWMLoginInputInfoModel

@end
