//
//  AppDelegate.h
//  MacDemo
//
//  Created by jdm on 11/3/21.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

