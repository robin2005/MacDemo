//
//  HWMInitViewController.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMInitViewController.h"
#import "HWMInputView.h"
#import <HWMUISDK/HWMUISDK.h>
#import "HWMSelectContactViewController.h"
#import "HWMSocialView.h"
#import "HWMAppKeyManager.h"
#import "HWMContactInfoModel.h"
#import "HWMToolBarConfigDataSource.h"
#import "HWMAttendeeManager.h"

@interface HWMInitViewController ()<HWMInputViewDelegate, HWMConfSettingHandler, HWMNotifyHandler, HWMContactUIHandler, HWMConfUIHandler, HWMSocialShareHandler, HWMBizNotificationHandler, HWMIncomingAnswerHandler>

/// id
@property (nonatomic, strong) HWMInputView *inputView;
/// 中国站点
@property (nonatomic, strong) NSButton *chBtn;
/// 国际
@property (nonatomic, strong) NSButton *inteBtn;
/// 中文
@property (nonatomic, strong) NSButton *zhBtn;
/// 英文
@property (nonatomic, strong) NSButton *enBtn;

@property (nonatomic, assign) HWMSdkLanguageType language;
/// 初始化按钮
@property (nonatomic, strong) NSButton *confirmBtn;
/// 站点类型
@property (nonatomic, assign) HWMSiteType siteType;
/// appKey
@property (nonatomic, copy) NSString *appId;

@property (nonatomic, strong) HWMSocialView *socialView;

@property (nonatomic, strong) HWMSelectContactViewController *selectContactVC;

@end

@implementation HWMInitViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
    ///  默认估计站点
    self.siteType = HWMSiteTypeChina;
    self.language = HWMSdkLanguageTypeZH;

    self.appId = [HWMAppKeyManager shareInstance].appId;
    self.inputView.textField.stringValue = self.appId;
}

- (void)dealloc {
    HWMOpenSDKConfig *config = [HWMSdk getSdkConfig];
    [config unsubscribeGlobalNotificationHandler:self];
    [config unsubscribeBizNotificationHandler:self];
}

#pragma mark - UI
- (void)setupUI {
    [self.view addSubview:self.inputView];
    [self.view addSubview:self.chBtn];
    [self.view addSubview:self.inteBtn];
    [self.view addSubview:self.zhBtn];
    [self.view addSubview:self.enBtn];
    [self.view addSubview:self.confirmBtn];

    [self.inputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(100);
        make.centerX.equalTo(self.view);
        make.height.mas_equalTo(50);
        make.width.mas_equalTo(350);
    }];

    [self.chBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.inputView.mas_left);
        make.top.equalTo(self.inputView.mas_bottom).offset(15);
    }];

    [self.inteBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.chBtn.mas_right).offset(15);
        make.top.equalTo(self.inputView.mas_bottom).offset(15);
    }];

    [self.zhBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.inputView.mas_left);
        make.top.equalTo(self.chBtn.mas_bottom).offset(30);
    }];

    [self.enBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.zhBtn.mas_right).offset(15);
        make.top.equalTo(self.inteBtn.mas_bottom).offset(30);
    }];

    [self.confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.zhBtn.mas_bottom).offset(80);
        make.height.mas_equalTo(35);
        make.width.mas_equalTo(250);
    }];
}

#pragma mark - Event

- (void)changeSite:(NSButton *)sender {
    if (self.inteBtn.state == NSControlStateValueOn) {
        self.siteType = HWMSiteTypeAP;
    } else {
        self.siteType = HWMSiteTypeChina;
    }
}

- (void)changeLanguage:(NSButton *)sender {
    if (self.zhBtn.state == NSControlStateValueOn) {
        self.language = HWMSdkLanguageTypeZH;
    } else {
        self.language = HWMSdkLanguageTypeEN;
    }
}

- (void)setAppLanguage {
    [HWMSdk setLanguage:self.language];
}

- (void)initSDK {
    if (self.appId.length == 0) {
        [HWMConsoleManager shareInstance].console = @"please input app id";
        return;
    }

    if ([HWMSdk hasInit]) {
        [HWMConsoleManager shareInstance].console = @"has init";
        return;
    }

    HWMOpenSDKConfig *config = [[HWMOpenSDKConfig alloc] init];
    config.appId = self.appId;
    config.siteType = self.siteType;
    BOOL success = [HWMSdk initWithConfig:config];
    [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%@", [config yy_modelDescription]];
    [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%lu", self.siteType];
    if (success) {
        [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"appId: %@", self.appId];
    } else {
        [HWMConsoleManager shareInstance].console = @"init failed";
    }

    [self setAppLanguage];
    [self configDelegate];
}

- (void)configDelegate {
    HWMOpenSDKConfig *config = [HWMSdk getSdkConfig];
    config.contactUIHandler = self;
    config.confSettingHandler = self;
    config.confUIHandler = self;
//    config.socialShareHandler = self;
    [config subscribeGlobalNotificationHandler:self];
    [config subscribeBizNotificationHandler:self];
    config.incomingAnswerHandler = self;
    config.toolbarItemHandler = [HWMToolBarConfigDataSource shareInstance];
}

#pragma mark - Delegate

- (void)textFieldDidChanged:(NSTextField *)field {
    self.appId = field.stringValue;
    if (self.appId.length > 0) {
        [HWMAppKeyManager shareInstance].appId = field.stringValue;
    }
}

- (BOOL)isOpenCameraIncoming {
    return YES;
}

- (BOOL)isOpenMicrophoneIncoming {
    return YES;
}

- (void)onCorpConfigNotify:(HWMCorpConfigInfo *)corpConfig {
    if (corpConfig.hasSMSPerm) {
        [HWMConsoleManager shareInstance].console = @"有发送短信通知权限";
    }
    if (corpConfig.hasRecordPerm) {
        [HWMConsoleManager shareInstance].console = @"有会议录制权限";
    }
    if (corpConfig.hasPstnPerm) {
        [HWMConsoleManager shareInstance].console = @"有PSTN外呼权限";
    }

    if (corpConfig.pstnNumber.length) {
        [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"PSTN呼叫接入号:%@", corpConfig.pstnNumber];
    }
}

/// 被挤下线
- (void)onKickedOut {
    [HWMConsoleManager shareInstance].console = @"Your account has been used to log in elsewhere";
}

/// 自定义联系人
- (void)openContactSelectWindow:(NSArray<HWMAttendeeInfo *> *)param scene:(HWMSelectedContactScene)scene completeHander:(void (^)(NSArray<HWMAttendeeInfo *> *_Nullable))handler {
    [HWMAttendeeManager logAttendees:param];

    HWMSelectContactViewController *contact = [[HWMSelectContactViewController alloc] init];
    [contact setSelectAttendeeInfoHandler:^(NSArray *attendees) {
        NSMutableArray *arr = @[].mutableCopy;
        for (HWMContactInfoModel *model in attendees) {
            HWMAttendeeInfo *info = [[HWMAttendeeInfo alloc] init];
            info.accountId = model.accountId;
            info.name = model.name;
            info.number = model.number;
            info.thirdUserId = model.thirdUserId;
            info.email = model.email;
            info.mute = model.mute;
            info.role = model.role;
            info.sms = model.sms;
            [arr addObject:info];
        }
        if (handler) {
            handler(arr);
        }
    }];
    self.selectContactVC = contact;
    [self presentViewControllerAsModalWindow:contact];
}

/// 关闭窗口
- (void)closeContactSelectWindow {
    if (self.selectContactVC) {
        [self.selectContactVC.view.window close];
        [NSApp stopModal];
    }
}

/// 设置视频通话时 视频窗口最小化dock栏图标 以及共享情况下吸附窗口显示的图标
- (NSImage *)videoWindowDockIcon {
    return [NSImage imageNamed:@"iconMeeting"];
}

/// 会中鼠标至于标题栏出现的分享View
- (NSView *)socialShareView:(HWMConfStateInfo *)confDetail {
    if (!self.socialView) {
        self.socialView =  [[HWMSocialView alloc] initWithFrame:NSMakeRect(0, 0, 500, 300)];
        self.socialView.wantsLayer = YES;
        self.socialView.layer.backgroundColor = [NSColor whiteColor].CGColor;
    }
    self.socialView.confDetail = confDetail;

    return self.socialView;
}

/// 会议信息改变回调
- (void)onConfInfoNotify:(HWMConfStateInfo *)confInfo
{
    [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"会中信息上报 onConfInfoNotify :%@", [confInfo yy_modelDescription]];
    self.socialView.confDetail = confInfo;
}

- (void)onLoginTokenRefreshNotify:(HWMLoginStatusInfo *)loginInfo {
    [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"login token: %@", loginInfo.loginToken];
}

#pragma mark - Lazy

- (HWMInputView *)inputView {
    if (!_inputView) {
        _inputView = [[HWMInputView alloc] init];
        _inputView.title = @"AppId:";
        _inputView.placeholder = @"请输入appId";
        _inputView.delegate = self;
    }
    return _inputView;
}

- (NSButton *)chBtn {
    if (!_chBtn) {
        _chBtn = [[NSButton alloc] init];
        _chBtn.bordered = NO;
        _chBtn.font = [NSFont systemFontOfSize:12];
        _chBtn.bezelStyle = NSBezelStyleRegularSquare;
        _chBtn.state = NSControlStateValueOn;
        [_chBtn setButtonType:NSButtonTypeRadio];
        [_chBtn setTitle:@"中国站点"];
        _chBtn.target = self;
        _chBtn.action = @selector(changeSite:);
        _chBtn.tag = 0;
    }
    return _chBtn;
}

- (NSButton *)inteBtn {
    if (!_inteBtn) {
        _inteBtn = [[NSButton alloc] init];
        _inteBtn.bordered = NO;
        _inteBtn.font = [NSFont systemFontOfSize:12];
        [_inteBtn setBezelStyle:NSBezelStyleRegularSquare];
        [_inteBtn setButtonType:NSButtonTypeRadio];
        [_inteBtn setState:NSControlStateValueOff];
        [_inteBtn setTitle:@"国际站点"];
        _inteBtn.target = self;
        _inteBtn.action = @selector(changeSite:);
        _inteBtn.tag = 1;
    }
    return _inteBtn;
}

- (NSButton *)zhBtn {
    if (!_zhBtn) {
        _zhBtn = [[NSButton alloc] init];
        _zhBtn.bordered = NO;
        _zhBtn.font = [NSFont systemFontOfSize:12];
        _zhBtn.bezelStyle = NSBezelStyleRegularSquare;
        _zhBtn.state = NSControlStateValueOn;
        [_zhBtn setButtonType:NSButtonTypeRadio];
        [_zhBtn setTitle:@"中文（会中界面）"];
        _zhBtn.target = self;
        _zhBtn.action = @selector(changeLanguage:);
        _zhBtn.tag = 0;
    }
    return _zhBtn;
}

- (NSButton *)enBtn {
    if (!_enBtn) {
        _enBtn = [[NSButton alloc] init];
        _enBtn.bordered = NO;
        _enBtn.font = [NSFont systemFontOfSize:12];
        [_enBtn setBezelStyle:NSBezelStyleRegularSquare];
        [_enBtn setButtonType:NSButtonTypeRadio];
        [_enBtn setState:NSControlStateValueOff];
        [_enBtn setTitle:@"英文（会中界面）"];
        _enBtn.target = self;
        _enBtn.action = @selector(changeLanguage:);
        _enBtn.tag = 1;
    }
    return _enBtn;
}

- (NSButton *)confirmBtn {
    if (!_confirmBtn) {
        _confirmBtn = [NSButton buttonWithTitle:@"初始化" font:nil fontColor:[NSColor whiteColor] target:self action:@selector(initSDK)];
        _confirmBtn.layer.backgroundColor = [NSColor colorWithRGB:0x0D94FF].CGColor;
        _confirmBtn.layer.cornerRadius = 4.0;
        _confirmBtn.layer.masksToBounds = YES;
    }
    return _confirmBtn;
}

- (HWMIncomingAnswerType)onIncomingCallAnswer {
    return HWMIncomingAnswerNormal;
}

@end
