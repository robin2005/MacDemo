//
//  HWMConsoleManager.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMConsoleManager.h"

@interface HWMConsoleManager ()

/// 历史记录
@property (nonatomic, copy) NSString *hisConsole;

@end

@implementation HWMConsoleManager

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    static HWMConsoleManager *manager = nil;
    dispatch_once(&onceToken, ^{
        manager = [[self alloc] init];
        manager.hisConsole = @"";
    });
    return manager;
}

- (void)setConsole:(NSString *)console {
    _console = console;
    NSDate *date = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSString *dateStr = [formatter stringFromDate:date];
    if (self.hisConsole.length > 0) {
        self.hisConsole = [NSString stringWithFormat:@"%@\n%@ %@", self.hisConsole, dateStr, console];
    }else {
        self.hisConsole = [NSString stringWithFormat:@"%@ %@", dateStr, console];
    }
    self.consoleView.console = self.hisConsole;
}

@end
