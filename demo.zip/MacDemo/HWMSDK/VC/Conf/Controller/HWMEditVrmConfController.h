//
//  HWMEditVrmConfController.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/2.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"
#import <HWMUISDK/HWMVmrInfoModel.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^EditVrmConfSuccessHandler)(void);

@interface HWMEditVrmConfController : HWMBaseViewController

/// vmrInfo
@property (nonatomic, strong) HWMVmrInfoModel *vmrInfoModel;
/// 编辑成功
@property (nonatomic, copy) EditVrmConfSuccessHandler editVrmConfSuccessHandler;

@end

NS_ASSUME_NONNULL_END
