//
//  HWMFunctionListView.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "HWMFunctionModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^FunctionSelectTypeHandler)(HWMFunctionType type);

@interface HWMFunctionListView : NSView
/// 选中回调
@property (nonatomic, copy) FunctionSelectTypeHandler functionSelectTypeHandler;

@end

NS_ASSUME_NONNULL_END
