//
//  HWMInitViewController.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMInitViewController : HWMBaseViewController

@end

NS_ASSUME_NONNULL_END
