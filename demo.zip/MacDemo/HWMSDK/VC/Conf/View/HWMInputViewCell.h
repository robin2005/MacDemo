//
//  HWMInputViewCell.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/28.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^InputViewDidEndEditerHandler)(NSString *content, NSInteger index);

@interface HWMInputViewCell : NSTableCellView

+ (instancetype)initInputViewCell:(NSTableView *)tableView ower:(nullable id)ower;

/// 预留字
@property (nonatomic, copy) NSString *placeholder;
/// 下标
@property (nonatomic, assign) NSInteger index;
/// 内容
@property (nonatomic, copy) NSString *content;
/// 编辑回调
@property (nonatomic, copy) InputViewDidEndEditerHandler inputViewDidEndEditerHandler;

@property (nonatomic, assign) BOOL enabled;
@end

NS_ASSUME_NONNULL_END
