//
//  HWMNavigationBar.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/2.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class HWMNavigationItem;
NS_ASSUME_NONNULL_BEGIN

@interface HWMNavigationBar : NSView

@property (nonatomic, strong) HWMNavigationItem *backItem;
@property (nonatomic, strong) HWMNavigationItem *rightItem;

@end

NS_ASSUME_NONNULL_END
