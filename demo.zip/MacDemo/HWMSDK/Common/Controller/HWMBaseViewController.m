//
//  HWMBaseViewController.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

@interface HWMBaseViewController ()

@end

@implementation HWMBaseViewController

- (void)loadView {
    self.view = [[NSView alloc] initWithFrame:NSZeroRect];
    self.view.wantsLayer = YES;
    self.view.layer.backgroundColor = [NSColor whiteColor].CGColor;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

@end
