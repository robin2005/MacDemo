//
//  HWMTextField.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/26.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMTextField.h"

@implementation HWMTextField

- (instancetype)initWithFrame:(NSRect)frameRect {
    if (self = [super initWithFrame:frameRect]) {
        self.focusRingType = NSFocusRingTypeNone;
        self.bordered = NO;
        self.cell.scrollable = YES;
        self.cell.usesSingleLineMode = YES;
    }
    return self;
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
