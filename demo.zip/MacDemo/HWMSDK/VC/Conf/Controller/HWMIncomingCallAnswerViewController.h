//
//  HWMIncomingCallAnswerViewController.h
//  HWMUISDKNativeDemo
//
//  Created by chenlinfeng on 2021/1/6.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "HWMBaseViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface HWMIncomingCallAnswerViewController : HWMBaseViewController

@end

NS_ASSUME_NONNULL_END
