//
//  HWMTableCellArrowView.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/2/19.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^ArrowCellViewClickHandler)(NSInteger index);

@interface HWMTableCellArrowView : NSTableCellView

+ (instancetype)tableViewArrowCell:(NSTableView *)tableView ower:(id)ower;

/// block
@property (nonatomic, copy) ArrowCellViewClickHandler arrowCellViewClickHandler;
/// 下标
@property (nonatomic, assign) NSInteger index;
/// 标题
@property (nonatomic, copy) NSString *title;

@end

NS_ASSUME_NONNULL_END
