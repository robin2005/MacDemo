//
//  NSTextField+HWMExtension.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSTextField (HWMExtension)

+ (instancetype)fieldWithTitle:(NSString *)title titleColor:(NSColor *)titleColor font:(NSFont *)font;
+ (instancetype)fieldWithTitle:(NSString *)title titleColor:(NSColor *)titleColor font:(NSFont *)font lineSpaceing:(CGFloat)space;

@end

NS_ASSUME_NONNULL_END
