//
//  HWMConsoleManager.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HWMConsoleView.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMConsoleManager : NSObject

+ (instancetype)shareInstance;
/// 控制台
@property (nonatomic, weak) HWMConsoleView *consoleView;
/// 日志
@property (nonatomic, copy) NSString *console;

@end

NS_ASSUME_NONNULL_END
