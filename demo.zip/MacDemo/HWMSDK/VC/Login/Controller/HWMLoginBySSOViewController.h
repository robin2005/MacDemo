//
//  HWMLoginBySSOViewController.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/8/17.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMLoginBySSOViewController : HWMBaseViewController

@end

NS_ASSUME_NONNULL_END
