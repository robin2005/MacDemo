//
//  HWMFunctionModel.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, HWMFunctionType) {
    HWMFunctionTypeInit,
    HWMFunctionTypeLogin,
    HWMFunctionTypeLoginWithAppID,
    HWMFunctionTypeCreateMeeting,
    HWMFunctionTypeJoinMeeting,
    HWMFunctionTypeLogOut,
    HWMFunctionTypeBookConf,
    HWMFunctionTypeConfList,
    HWMFunctionTypeVmrList,
};

@interface HWMFunctionModel : NSObject

/// 功能名字
@property (nonatomic, strong) NSString *name;
/// 类型
@property (nonatomic, assign) HWMFunctionType type;
/// 类型
@property (nonatomic, assign, getter=isSelected) BOOL selected;

@end

NS_ASSUME_NONNULL_END
