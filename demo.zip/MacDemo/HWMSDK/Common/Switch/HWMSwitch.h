//
//  HWMSwitch.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/27.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMSwitch : NSControl

@property (nonatomic, assign) BOOL checked;
@property (nonatomic, strong) NSColor *tintColor;
@property (nonatomic, strong) NSColor *disabledBorderColor;

@end

NS_ASSUME_NONNULL_END
