//
//  HWMFunctionListCell.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@class HWMFunctionModel;

typedef void(^FunctionClickDownHandler)(HWMFunctionModel *model);

@interface HWMFunctionListCell : NSTableCellView
/// model
@property (nonatomic, strong) HWMFunctionModel *model;
/// 操作
@property (nonatomic, copy) FunctionClickDownHandler functionClickDownHandler;
@end

NS_ASSUME_NONNULL_END
