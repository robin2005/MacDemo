//
//  HWMJoinConfLimitCell.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/3.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMJoinConfLimitCell.h"

@interface HWMJoinConfLimitCell ()
/// 标题
@property (nonatomic, strong) NSTextField *titleLabel;
/// 范围
@property (nonatomic, strong) NSButton *limitLabel;

@end

@implementation HWMJoinConfLimitCell

+ (instancetype)joinConfLimitCell:(NSTableView *)tableView ower:(id)ower {
    HWMJoinConfLimitCell *cell = [tableView makeViewWithIdentifier:NSStringFromClass([HWMJoinConfLimitCell class]) owner:ower];
    if (!cell) {
        cell = [[HWMJoinConfLimitCell alloc] initWithFrame:NSZeroRect];
        cell.identifier = NSStringFromClass([HWMJoinConfLimitCell class]);
    }
    return cell;
}

- (instancetype)initWithFrame:(NSRect)frameRect {
    if (self = [super initWithFrame:frameRect]) {
        self.wantsLayer = YES;
        self.layer.backgroundColor = [NSColor whiteColor].CGColor;
        [self setupUI];
    }
    return self;
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];

    // Drawing code here.
}

#pragma mark - UI
- (void)setupUI {
    [self addSubview:self.titleLabel];
    [self addSubview:self.limitLabel];

    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(120);
        make.centerY.equalTo(self);
        make.width.mas_equalTo(100);
    }];

    [self.limitLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).offset(-120);
        make.centerY.equalTo(self);
    }];
}

#pragma mark - Event
- (void)limitBtnClick {
    NSMenu *menu = [[NSMenu alloc] init];
    NSArray *arr = @[@"所有人", @"仅企业内人员", @"仅会议邀请人员"];

    for (NSInteger i = 0; i < arr.count; i++) {
        NSString *title = arr[i];
        NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:title action:@selector(selectMenuItem:) keyEquivalent:@""];
        item.target = self;
        item.tag = i;
        [menu addItem:item];
    }
    NSPoint point = NSMakePoint(self.frame.origin.x, self.frame.origin.y + 30);
    [menu popUpMenuPositioningItem:nil atLocation:point inView:self.limitLabel];
    [menu cancelTrackingWithoutAnimation];
}

- (void)selectMenuItem:(NSMenuItem *)item {
    NSString *title = item.title;
    NSMutableAttributedString *att = [[NSMutableAttributedString alloc] initWithString:title];
    [att addAttributes:@{ NSFontAttributeName: [NSFont systemFontOfSize:13], NSForegroundColorAttributeName:[NSColor colorWithRGB:0x333333] } range:NSMakeRange(0, title.length)];
    self.limitLabel.attributedTitle = att;
    NSInteger type = item.tag;
    if (type > 0) {
        type = type + 1;
    }
    if (self.joinConfLimitSelectHandler) {
        self.joinConfLimitSelectHandler(type);
    }
}

- (void)setType:(NSInteger)type {
    _type = type;
    NSString *title;
    if (type == 0) {
        title = @"所有人";
    }else if (type == 2) {
        title = @"仅企业内人员";
    }else {
        title = @"仅会议邀请人员";
    }
    NSMutableAttributedString *att = [[NSMutableAttributedString alloc] initWithString:title];
    [att addAttributes:@{ NSFontAttributeName: [NSFont systemFontOfSize:13], NSForegroundColorAttributeName:[NSColor colorWithRGB:0x333333] } range:NSMakeRange(0, title.length)];
    self.limitLabel.attributedTitle = att;
}

#pragma mark - Lazy
- (NSTextField *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [NSTextField fieldWithTitle:@"允许入会" titleColor:[NSColor colorWithRGB:0x666666] font:[NSFont systemFontOfSize:13]];
    }
    return _titleLabel;
}

- (NSButton *)limitLabel {
    if (!_limitLabel) {
        _limitLabel = [NSButton buttonWithTitle:@"所有人" font:[NSFont systemFontOfSize:13] fontColor:[NSColor blackColor] target:self action:@selector(limitBtnClick)];
        _limitLabel.layer.backgroundColor = [NSColor whiteColor].CGColor;
        _limitLabel.image = [NSImage imageNamed:@"arrow_right"];
        _limitLabel.imagePosition = NSImageRight;
    }
    return _limitLabel;
}



@end
