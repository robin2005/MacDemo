//
//  NSString+HWMExtension.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/3.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (HWMExtension)

+ (NSString *)getLocalTimeZoneTimeWithTimeInterval:(NSTimeInterval)timeInteral
                                           formart:(NSString *)formart;

+ (NSTimeInterval)getTimeIntervalWithDateString:(NSString *)dateString;

+ (NSString *)timeStringFromTimeInterval:(NSTimeInterval)timeInteral;

@end

NS_ASSUME_NONNULL_END
