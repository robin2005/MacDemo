//
//  HWMConfListItem.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/29.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <HWMUISDK/HWMUISDK.h>

NS_ASSUME_NONNULL_BEGIN
typedef void(^VmrListItemClickHandler)(HWMVmrInfoModel *vmrInfo);
typedef void(^JoinConfClickHandler)(HWMConfListItemInfo *itemInfo);

@interface HWMConfListItem : NSTableCellView

+ (instancetype)initConfListItem:(NSTableView *)tableView ower:(nullable id)ower;

/// 会议item
@property (nonatomic, strong) HWMConfListItemInfo *itemInfo;
/// Vrm item
@property (nonatomic, strong) HWMVmrInfoModel *vmrInfo;
/// 编辑Vmr回调
@property (nonatomic, copy) VmrListItemClickHandler vmrListItemClickHandler;

@property (nonatomic, copy) JoinConfClickHandler joinConfClickHandler;

@end

NS_ASSUME_NONNULL_END
