//
//  HWMUserStateController.h
//  HWMUISDKNativeDemo
//
//  Created by linweiqiang on 2021/3/15.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMUserStateController : HWMBaseViewController

@end

NS_ASSUME_NONNULL_END
