//
//  HWMCreateConfViewController.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMCreateConfViewController.h"
#import "HWMInputViewCell.h"
#import "HWMConfTypeSelectCell.h"
#import "HWMSwitchCell.h"
#import <HWMUISDK/HWMUISDK.h>
#import "HWMSelectVrmViewController.h"
#import "HWMSelectContactViewController.h"
#import "HWMTableView.h"
#import "HWMJoinConfLimitCell.h"
#import "HWMContactInfoModel.h"

@interface HWMCreateConfViewController ()<HWMTableViewDelegate, HWMTableViewDataSourse, HWMSwitchCellDelegate, HWMBizNotificationHandler>
/// 按钮
@property (nonatomic, strong) NSButton *createBtn;
/// 标题
@property (nonatomic, copy) NSArray *titlesArr;
/// 创建会议参数
@property (nonatomic, strong) HWMCreateConfParam *confParam;
/// vmrList
@property (nonatomic, strong) NSMutableArray <HWMVmrInfoModel *> *vmrList;
/// 是否使用vmrID
@property (nonatomic, assign) BOOL useVmrId;
/// vmr 会议ID
@property (nonatomic, copy) NSString *vmrConfID;
/// 是否携带与会者
@property (nonatomic, assign) BOOL needAttendee;
/// tableView
@property (nonatomic, strong) HWMTableView *listView;
@end

@implementation HWMCreateConfViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupData];
    [self setupUI];
}

- (void)viewWillAppear {
    [super viewWillAppear];
    /// 订阅要在初始化后根据需要设置
    [self configNotification];
    [self getVmrList];
    [self resetAttendee];
}

#pragma mark - Data
- (void)setupData {
    self.vmrConfID = @"";
    self.titlesArr = @[@"", @"使用个人会议ID", @"是否需要携带与会者", @"允许入会", @"打开摄像头", @"打开麦克风", @"打开会议录制", @"是否设置来宾密码",@""];
}

- (void)resetAttendee {
    self.needAttendee = NO;
    self.confParam.members = @[];
    [self.listView reloadData];
}

- (void)getVmrList {
    if (![HWMSdk hasInit]) {
        return;
    }
    @weakify(self)
    [[HWMBizSdk getBizOpenApi] getVmrList:^(NSError *_Nullable error, NSArray<HWMVmrInfoModel *> *_Nullable result) {
        @strongify(self)
        if (error) {
            [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%@", error.description];
        } else {
            [self.vmrList removeAllObjects];
            for (HWMVmrInfoModel *vmrInfo in result) {
                if (vmrInfo.usable && (vmrInfo.confId.length > 0 || vmrInfo.vmrId.length > 0)) {
                    [self.vmrList addObject:vmrInfo];
                }
            }
            self.vmrConfID = self.vmrList.count == 1 ? self.vmrList.firstObject.confId : @"";
            [self.listView reloadData];
        }
    }];
}

#pragma mark - UI
- (void)setupUI {
    self.listView = [[HWMTableView alloc] initTableViewClomuIdentifier:@"createConf"];
    self.listView.delegate = self;
    self.listView.dataSource = self;
    [self.view addSubview:self.listView];
    [self.listView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.equalTo(self.view).offset(15);
        make.right.equalTo(self.view).offset(-15);
        make.bottom.equalTo(self.view).offset(-100);
    }];

    [self.view addSubview:self.createBtn];
    [self.createBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-20);
        make.height.mas_equalTo(35);
        make.width.mas_equalTo(250);
    }];
}

#pragma mark - Delegate
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return self.titlesArr.count;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    if (row == 0) {
        HWMInputViewCell *cell = [HWMInputViewCell initInputViewCell:tableView ower:self];
        cell.placeholder = @"会议主题（必填）";
        cell.content = self.confParam.subject;
        @weakify(self)
        [cell setInputViewDidEndEditerHandler:^(NSString *_Nonnull content, NSInteger index) {
            @strongify(self)
            self.confParam.subject = content;
        }];
        cell.enabled = YES;
        return cell;
    }
    
    if (row == 8) {
        HWMInputViewCell *cell = [HWMInputViewCell initInputViewCell:tableView ower:self];
        cell.placeholder = @"来宾密码（不填使用随机密码）";
        cell.content = self.confParam.guestPwd;
        @weakify(self)
        [cell setInputViewDidEndEditerHandler:^(NSString *_Nonnull content, NSInteger index) {
            @strongify(self)
            self.confParam.guestPwd = content;
        }];
        cell.enabled = !self.useVmrId && !self.confParam.noPassword;
        return cell;
    }

    if (row == 3) {
        HWMJoinConfLimitCell *cell = [HWMJoinConfLimitCell joinConfLimitCell:tableView ower:self];
        cell.type = self.confParam.callInRestrictionType;
        @weakify(self)
        [cell setJoinConfLimitSelectHandler:^(NSInteger type) {
            @strongify(self)
            self.confParam.callInRestrictionType = type;
        }];
        return cell;
    }

    HWMSwitchCell *cell = [HWMSwitchCell initSwitchCell:tableView ower:self];
    cell.index = row;
    cell.delegate = self;
    if (row == 1) {
        cell.state = self.useVmrId;
        NSString *title = [NSString stringWithFormat:@"%@ %@", self.titlesArr[1], self.vmrConfID];
        cell.title = title;
    } else {
        cell.title =  self.titlesArr[row];
        if (row == 2) {
            cell.state = self.needAttendee;
        } else if (row == 4) {
            cell.state = self.confParam.isCameraOn;
        } else if (row == 5) {
            cell.state = self.confParam.isMicOn;
        } else if (row == 6){
            cell.state = self.confParam.isAutoRecord;
        } else if (row == 7) {
            cell.state = !self.confParam.noPassword;
            cell.enabled = !self.useVmrId;
        }
    }
    return cell;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 40.0;
}

- (void)switchStateChanged:(BOOL)state index:(NSInteger)index {
    NSLog(@"%hhd, %lu", state, index);
    HWMSwitchCell *cell = [self.listView.listView viewAtColumn:0 row:index makeIfNecessary:YES];
    switch (index) {
        case 1: {
            if (self.vmrList.count == 0) {
                [HWMConsoleManager shareInstance].console = @"没有可用个人会议ID";
                cell.state = NO;
            } else if (self.vmrList.count == 1) {
                self.confParam.vmrId = state ? self.vmrList.firstObject.vmrId : @"";
                self.useVmrId = state;
                HWMInputViewCell *pwdTextCell = [self.listView.listView viewAtColumn:0 row:8 makeIfNecessary:YES];
                HWMSwitchCell *pwdCell = [self.listView.listView viewAtColumn:0 row:7 makeIfNecessary:YES];
                pwdCell.enabled = !self.useVmrId;
                pwdTextCell.enabled = !self.useVmrId && !self.confParam.noPassword;
            } else {
                if (state) {
                    cell.state = NO;
                    HWMSelectVrmViewController *selectVrm = [[HWMSelectVrmViewController alloc] init];
                    selectVrm.vmrArr = self.vmrList;
                    @weakify(self)
                    [selectVrm setSelectVrmInfoHandler:^(HWMVmrInfoModel *_Nonnull infoModel) {
                        @strongify(self)
                        if (infoModel) {
                            self.vmrConfID = infoModel.confId;
                            self.confParam.vmrId = infoModel.vmrId;
                            cell.state = YES;
                            self.useVmrId = YES;
                            [self.listView reloadData];
                        }
                    }];
                    [self presentViewControllerAsModalWindow:selectVrm];
                }else {
                    self.useVmrId = NO;
                    self.confParam.vmrId = @"";
                }
            }
        }
        break;
        case 2: {
            if (state == NO) {
                self.needAttendee = NO;
                self.confParam.members = @[];
                return;
            }
            cell.state = NO;
            HWMSelectContactViewController *contact = [[HWMSelectContactViewController alloc] init];
            @weakify(self)
            [contact setSelectAttendeeInfoHandler:^(NSArray *_Nullable attendees) {
                @strongify(self)
                NSMutableArray *arr = @[].mutableCopy;
                for (HWMContactInfoModel *model in attendees) {
                    HWMAttendeeInfo *info = [[HWMAttendeeInfo alloc] init];
                    info.accountId = model.accountId;
                    info.name = model.name;
                    info.number = model.number;
                    info.thirdUserId = model.thirdUserId;
                    info.email = model.email;
                    info.mute = model.mute;
                    info.role = model.role;
                    info.sms = model.sms;
                    [arr addObject:info];
                }
                self.confParam.members = arr;
                if (arr.count > 0) {
                    self.needAttendee = YES;
                    cell.state = YES;
                } else {
                    self.needAttendee = NO;
                }
            }];
            [self presentViewControllerAsModalWindow:contact];
        }
        break;
        case 4:
            self.confParam.isCameraOn = state;
            break;
        case 5:
            self.confParam.isMicOn = state;
            break;
        case 6:
            self.confParam.isAutoRecord = state;
            break;
        case 7:
        {
            self.confParam.noPassword = !state;
            HWMInputViewCell *pwdCell = [self.listView.listView viewAtColumn:0 row:8 makeIfNecessary:YES];
            pwdCell.enabled = !self.useVmrId && !self.confParam.noPassword;
        }
            break;
        default:
            break;
    }
}

/// 会议状态变更通知
- (void)onConfStatusChanged:(HWMConfStatus)status {
    switch (status) {
        case HWMConfStatusIdle:
            [HWMConsoleManager shareInstance].console = @"会议结束";
            break;
        case HWMConfStatusIncoming:
            [HWMConsoleManager shareInstance].console = @"正在来电";
            break;
        case HWMConfStatusCallingOut:
            [HWMConsoleManager shareInstance].console = @"正在呼出";
            break;
        case HWMConfStatusConnected:
            [HWMConsoleManager shareInstance].console = @"已接通";
            break;

        default:
            break;
    }
}

/// 个人角色是否是主持人变化通知
- (void)onSelfRoleChanged:(HWMConfRoleType)confRole {
    switch (confRole) {
        case HWMConfRoleTypeAttendee:
            [HWMConsoleManager shareInstance].console = @"与会者";
            break;
        case HWMConfRoleTypeAudience:
            [HWMConsoleManager shareInstance].console = @"观众";
            break;
        case HWMConfRoleTypeChairman:
            [HWMConsoleManager shareInstance].console = @"主持人";
            break;

        default:
            break;
    }
}

#pragma mark - Event

- (void)configNotification {
    [[HWMSdk getSdkConfig] subscribeBizNotificationHandler:self];
}

- (void)createConf {
    if (self.confParam.subject.length == 0) {
        [HWMConsoleManager shareInstance].console = @"subject can not be nil";
        return;
    }

    [[HWMSdk getOpenApi] createConf:self.confParam callback:^(NSError *_Nullable error, HWMCreateConfResult *_Nullable result) {
        if (error) {
            [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%@", error.description];
        } else {
            [HWMConsoleManager shareInstance].console = [NSString stringWithFormat:@"%@", [result yy_modelDescription]];
        }
    }];
}

#pragma mark - Lazy
- (NSButton *)createBtn {
    if (!_createBtn) {
        _createBtn = [NSButton buttonWithTitle:@"创建会议" font:nil fontColor:[NSColor whiteColor] target:self action:@selector(createConf)];
        _createBtn.layer.backgroundColor = [NSColor colorWithRGB:0x0D94FF].CGColor;
        _createBtn.layer.cornerRadius = 4.0;
        _createBtn.layer.masksToBounds = YES;
    }
    return _createBtn;
}

- (HWMCreateConfParam *)confParam {
    if (!_confParam) {
        _confParam = [[HWMCreateConfParam alloc] init];
    }
    return _confParam;
}

- (NSMutableArray<HWMVmrInfoModel *> *)vmrList {
    if (!_vmrList) {
        _vmrList = [NSMutableArray array];
    }
    return _vmrList;
}

@end
