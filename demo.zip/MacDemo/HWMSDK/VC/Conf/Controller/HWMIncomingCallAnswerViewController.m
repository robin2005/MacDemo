//
//  HWMIncomingCallAnswerViewController.m
//  HWMUISDKNativeDemo
//
//  Created by chenlinfeng on 2021/1/6.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMIncomingCallAnswerViewController.h"
#import <HWMUISDK/HWMUISDK.h>

@interface HWMIncomingCallAnswerViewController ()<HWMIncomingAnswerHandler>

@property (nonatomic, strong) NSButton *normalBtn;
@property (nonatomic, strong) NSButton *declineBtn;
@property (nonatomic, strong) NSButton *answerBtn;
@property (nonatomic, assign) HWMIncomingAnswerType answerType;
@end

@implementation HWMIncomingCallAnswerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    self.answerType = HWMIncomingAnswerNormal;
    [self setupUI];
    [HWMSdk getSdkConfig].incomingAnswerHandler = self;
}
#pragma mark - UI
- (void)setupUI {
    [self.view addSubview:self.normalBtn];
    [self.view addSubview:self.declineBtn];
    [self.view addSubview:self.answerBtn];
    
    [self.normalBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(100);
        make.left.equalTo(self.view).offset(50);
    }];
    
    [self.declineBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(100);
        make.centerX.equalTo(self.view);
    }];
    
    [self.answerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(100);
        make.right.equalTo(self.view).offset(-50);
    }];

}

#pragma mark - Lazy
- (NSButton *)normalBtn {
    if (!_normalBtn) {
        _normalBtn = [[NSButton alloc] init];
        _normalBtn.bordered = NO;
        _normalBtn.font = [NSFont systemFontOfSize:12];
        _normalBtn.bezelStyle = NSBezelStyleRegularSquare;
        _normalBtn.state = NSControlStateValueOn;
        [_normalBtn setButtonType:NSButtonTypeRadio];
        [_normalBtn setTitle:@"原始体验"];
        _normalBtn.target = self;
        _normalBtn.action = @selector(setIncomingAnswerType:);
        _normalBtn.tag = 0;
    }
    return _normalBtn;
}

- (NSButton *)declineBtn {
    if (!_declineBtn) {
        _declineBtn = [[NSButton alloc] init];
        _declineBtn.bordered = NO;
        _declineBtn.font = [NSFont systemFontOfSize:12];
        _declineBtn.bezelStyle = NSBezelStyleRegularSquare;
        _declineBtn.state = NSControlStateValueOff;
        [_declineBtn setButtonType:NSButtonTypeRadio];
        [_declineBtn setTitle:@"自动拒接"];
        _declineBtn.target = self;
        _declineBtn.action = @selector(setIncomingAnswerType:);
        _declineBtn.tag = 1;
    }
    return _declineBtn;
}

- (NSButton *)answerBtn {
    if (!_answerBtn) {
        _answerBtn = [[NSButton alloc] init];
        _answerBtn.bordered = NO;
        _answerBtn.font = [NSFont systemFontOfSize:12];
        [_answerBtn setBezelStyle:NSBezelStyleRegularSquare];
        [_answerBtn setButtonType:NSButtonTypeRadio];
        [_answerBtn setState:NSControlStateValueOff];
        [_answerBtn setTitle:@"自动接听"];
        _answerBtn.target = self;
        _answerBtn.action = @selector(setIncomingAnswerType:);
        _answerBtn.tag = 2;
    }
    return _answerBtn;
}

- (void)setIncomingAnswerType:(id)sender {
    NSButton *btn = (NSButton *)sender;
    switch (btn.tag) {
        case 0:
            self.answerType = HWMIncomingAnswerNormal;
            break;
        case 1:
            self.answerType = HWMIncomingAnswerAutoDecline;
            break;
        case 2:
            self.answerType = HWMIncomingAnswerAutoAnswer;
            break;
        default:
            break;
    }
}

- (HWMIncomingAnswerType) answerTypeOnCallIncoming {
    return self.answerType;
}

- (HWMIncomingAnswerType) answerTypeOnConfIncoming {
    return self.answerType;
}
@end
