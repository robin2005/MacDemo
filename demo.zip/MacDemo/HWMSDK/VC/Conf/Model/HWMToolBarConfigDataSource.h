//
//  HWMToolBarConfigDataSource.h
//  HWMUISDKNativeDemo
//
//  Created by tyfinal on 2021/6/28.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <HWMUISDK/HWMConfCtrlItemHandler.h>
#import "HWMItemConfigModel.h"
typedef NS_ENUM(NSInteger,HWMToolBarItemConfig) {
    HWMToolBarItemConfigDefault = 0,
    HWMToolBarItemConfigReceiveInput,
    HWMToolBarItemConfigUseInner,
};

NS_ASSUME_NONNULL_BEGIN

@interface HWMToolBarConfigDataSource : NSObject<HWMConfCtrlItemHandler>

+ (instancetype)shareInstance;

@property (nonatomic, assign) HWMToolBarItemConfig itemConfig;
@property (nonatomic, strong) HWMItemConfigModel *configModel;

@end

NS_ASSUME_NONNULL_END
