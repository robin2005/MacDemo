//
//  HWMConfDetailViewController.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/2.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMConfDetailViewController : HWMBaseViewController

/// 会议ID
@property (nonatomic, copy) NSString *confId;

@end

NS_ASSUME_NONNULL_END
