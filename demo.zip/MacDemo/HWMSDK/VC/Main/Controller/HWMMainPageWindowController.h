//
//  HWMMainPageWindowController.h
//  HWMUISDKNativeDemo
//
//  Created by HuLinjie on 2020/10/21.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMMainPageWindowController : NSWindowController

- (NSWindow *)createDefaultWindow;

@end

NS_ASSUME_NONNULL_END
