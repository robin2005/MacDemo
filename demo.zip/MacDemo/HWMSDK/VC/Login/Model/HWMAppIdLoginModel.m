//
//  HWMAppIdLoginModel.m
//  HWMUISDKNativeDemo
//
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMAppIdLoginModel.h"

@implementation HWMAppIdLoginModel

@end
