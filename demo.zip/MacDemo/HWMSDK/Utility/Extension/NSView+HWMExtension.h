//
//  NSView+HWMExtension.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSView (HWMExtension)

/// 添加鼠标区域
- (void)addTrackingArea;

- (void)addTrackingAreaWithRect:(NSRect)rect;

@end

NS_ASSUME_NONNULL_END
