//
//  HWMGlobalConfigController.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/1/12.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMGlobalConfigController.h"
#import "HWMTableView.h"
#import "HWMSwitchCell.h"
#import <HWMUISDK/HWMUISDK.h>
#import "HWMTableCellArrowView.h"
#import "HWMConfigServerController.h"
#import "NSViewController+HWMNavigation.h"
#import "HWMFileManager.h"

@interface HWMGlobalConfigController ()<HWMTableViewDataSourse, HWMTableViewDelegate, HWMSwitchCellDelegate, HWMBizNotificationHandler>
/// tableView
@property (nonatomic, strong) HWMTableView *listView;
/// data
@property (nonatomic, copy) NSArray *dataArr;

@end

@implementation HWMGlobalConfigController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupData];
    [self setupUI];
    [self setupDelegate];
}

#pragma mark - Data
- (void)setupData {
    self.dataArr = @[@"隐藏外部标签", @"隐藏允许入会",@"获取音频流", @"服务器设置", @"返回会议"];
}

#pragma mark - UI
- (void)setupUI {
    self.listView = [[HWMTableView alloc] initTableViewClomuIdentifier:@"globalConfig"];
    self.listView.delegate = self;
    self.listView.dataSource = self;
    [self.view addSubview:self.listView];
    [self.listView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.equalTo(self.view).offset(15);
        make.right.equalTo(self.view).offset(-15);
        make.bottom.equalTo(self.view).offset(-15);
    }];
}

#pragma mark - Config delegate
- (void)setupDelegate {
    [[HWMSdk getSdkConfig] subscribeBizNotificationHandler:self];
}

#pragma mark - Delegate
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return self.dataArr.count;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    if (row == 3 || row == 4) {
        HWMTableCellArrowView *arrow = [HWMTableCellArrowView tableViewArrowCell:tableView ower:self];
        arrow.index = row;
        arrow.title = self.dataArr[row];
        @weakify(self)
        [arrow setArrowCellViewClickHandler:^(NSInteger index) {
            @strongify(self)
            if (index == 3) {
                HWMConfigServerController *config = [[HWMConfigServerController alloc] init];
                
                [self.customNavigationController pushViewController:config animated:YES];
            }
            
            if (index == 4) {
                [[HWMBizSdk getBizOpenApi] showMeetingWindow];
            }
            
        }];
        return arrow;
    }
    HWMSwitchCell *cell = [HWMSwitchCell initSwitchCell:tableView ower:self];
    cell.index = row;
    cell.title = self.dataArr[row];
    cell.delegate = self;
    if (row == 0) {
        cell.state = [[HWMSdk getSdkConfig] hideExternalLabel];
    }
    return cell;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    return 40.0;
}

- (void)switchStateChanged:(BOOL)state index:(NSInteger)index {
    HWMSwitchCell *cell = [self.listView.listView viewAtColumn:0 row:index makeIfNecessary:NO];
    if ([HWMSdk hasInit]) {
        if (index == 0) {
            [[HWMSdk getSdkConfig] setHideExternalLabel:state];
        } else if (index == 1) {
            [[HWMSdk getSdkConfig] setHideAllowJoinConfMenu:state];
        }else if (index == 2) {
            [[HWMBizSdk getBizOpenApi] setAudioRawDataOutputConfig:state];
        }
    }else {
        cell.state = NO;
        [HWMConsoleManager shareInstance].console = @"no init";
    }
}

- (void)onAudioFrameDataNotify:(HWMAudioFrameDataModel *)pFrame {
    NSString *pcmPath = [NSString stringWithFormat:@"%@/audio_reocd.pcm", [HWMFileManager pcmPath]];
    FILE *_fb;
    _fb = fopen(pcmPath.UTF8String, "ab+");
    if (_fb && pFrame.pBuffer.length > 0) {
        size_t bufferL = pFrame.iSamples * pFrame.iBytesPerSample * pFrame.iChannels;
        fwrite(pFrame.pBuffer.bytes, 1, bufferL, _fb);
        fclose(_fb);
    }
}

@end
