//
//  HWMConfDetailItemModel.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/3.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMConfDetailItemModel.h"

@implementation HWMConfDetailItemModel

@end
