//
//  NSColor+HWMExtension.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/24.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "NSColor+HWMExtension.h"

@implementation NSColor (HWMExtension)

+ (NSColor *)colorWithRGB:(uint32_t)rgbValue
{
    float red = ((rgbValue & 0xFF0000) >> 16) / 255.0;
    float green = ((rgbValue & 0x00FF00) >> 8) / 255.0;
    float blue = ((rgbValue & 0x0000FF)) / 255.0;
    return [NSColor colorWithRed:red green:green blue:blue alpha:1.0];
}

+ (NSColor *)colorWithRGB:(uint32_t)rgbValue alpha:(CGFloat)alpha
{
    float red = ((rgbValue & 0xFF0000) >> 16) / 255.0;
    float green = ((rgbValue & 0x00FF00) >> 8) / 255.0;
    float blue = ((rgbValue & 0x0000FF)) / 255.0;
    return [NSColor colorWithRed:red green:green blue:blue alpha:alpha];
}

+ (NSColor *)colorWithRGBA:(uint32_t)rgbaValue
{
    float alpha = ((rgbaValue & 0xFF000000) >> 24) / 255.0;
    float red = ((rgbaValue & 0x00FF0000) >> 16) / 255.0;
    float green = ((rgbaValue & 0x0000FF00) >> 8) / 255.0;
    float blue = (rgbaValue & 0x000000FF) / 255.0;
    return [NSColor colorWithRed:red green:green blue:blue alpha:alpha];
}

+ (NSColor *)colorWithR:(float)r g:(float)g b:(float)b
{
    return [NSColor colorWithRed:r / 255.0 green:g / 255.0 blue:b / 255.0 alpha:1];
}

+ (NSColor *)randomColor {
    return [self colorWithR:arc4random() % 255 g:arc4random() % 255 b:arc4random() % 255];
}


@end
