//
//  HWMJoinConfLimitCell.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/3.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^JoinConfLimitSelectHandler)(NSInteger type);

@interface HWMJoinConfLimitCell : NSTableCellView

+ (instancetype)joinConfLimitCell:(NSTableView *)tableView ower:(id)ower;

/// 类型
@property (nonatomic, copy) JoinConfLimitSelectHandler joinConfLimitSelectHandler;
///类型
@property (nonatomic, assign) NSInteger type;

@end

NS_ASSUME_NONNULL_END
