//
//  HWMGetAttendeeListController.h
//  HWMUISDKNativeDemo
//
//  Created by guoyongliang/gwx917154 on 2021/7/9.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMGetAttendeeListController : HWMBaseViewController

@end

NS_ASSUME_NONNULL_END
