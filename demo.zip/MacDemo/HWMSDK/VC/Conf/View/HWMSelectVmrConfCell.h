//
//  HWMSelectVmrConfCell.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/6.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^SelectVmrConfHandler)(NSInteger index);

@class HWMVmrInfoModel;

@interface HWMSelectVmrConfCell : NSTableCellView

+ (instancetype)initSelectVmrConfCell:(NSTableView *)tableView ower:(id)ower;

/// 下标
@property (nonatomic, assign) NSInteger index;
/// 状态
@property (nonatomic, assign) BOOL select;
/// 回调
@property (nonatomic, copy) SelectVmrConfHandler selectVmrConfHandler;
/// model
@property (nonatomic, strong) HWMVmrInfoModel *infoModel;

@end

NS_ASSUME_NONNULL_END
