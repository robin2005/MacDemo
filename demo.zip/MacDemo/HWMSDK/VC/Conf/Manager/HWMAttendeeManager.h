//
//  HWMAttendeeManager.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/8/24.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <HWMUISDK/HWMUISDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMAttendeeManager : NSObject

+ (void)logAttendees:(NSArray <HWMAttendeeInfo *> *)attendees;

@end

NS_ASSUME_NONNULL_END
