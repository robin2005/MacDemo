//
//  NSViewController+HWMNavigation.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/2.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "HWMNavigationController.h"
#import "HWMNavigationBar.h"

@class HWMNavigationItem;
NS_ASSUME_NONNULL_BEGIN

@interface NSViewController (HWMNavigation)

@property (nonatomic, strong, readonly) HWMNavigationBar *customNavigationBar;
@property (nonatomic, strong) HWMNavigationItem *backItem;
@property (nonatomic, assign) BOOL hideNavBarWhenPush;
@property(nonatomic, strong, readonly) HWMNavigationController *customNavigationController;

@end

NS_ASSUME_NONNULL_END
