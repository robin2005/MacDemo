//
//  HWMAppKeyManager.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/16.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMAppKeyManager : NSObject

+ (instancetype)shareInstance;

/// appID
@property (nonatomic, copy) NSString *appId;
/// appKey
@property (nonatomic, copy) NSString *appKey;


@end

NS_ASSUME_NONNULL_END
