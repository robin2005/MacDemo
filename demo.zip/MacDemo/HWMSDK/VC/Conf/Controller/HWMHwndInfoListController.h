//
//  HWMHwndInfoListController.h
//  HWMUISDKNativeDemo
//
//  Created by linweiqiang on 2021/7/23.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMHwndInfoListController : HWMBaseViewController

@end

NS_ASSUME_NONNULL_END
