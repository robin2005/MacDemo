//
//  HWMContactInfoModel.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/12/8.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMContactInfoModel.h"

@implementation HWMContactInfoModel

@end
