//
//  HWMGlobalConfigController.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/1/12.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWMGlobalConfigController : HWMBaseViewController

@end

NS_ASSUME_NONNULL_END
