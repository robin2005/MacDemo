//
//  HWMFileManager.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/7/26.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMFileManager : NSObject

+ (NSString *)applicationSupportDir;

+ (NSString *)pcmPath;

@end

NS_ASSUME_NONNULL_END
