//
//  HWMSelectContactViewController.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/4.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"

typedef void(^SelectAttendeeInfoHandler)(NSArray * _Nullable attendees);

NS_ASSUME_NONNULL_BEGIN

@interface HWMSelectContactViewController : HWMBaseViewController

@property (nonatomic, copy) SelectAttendeeInfoHandler selectAttendeeInfoHandler;

@end

NS_ASSUME_NONNULL_END
