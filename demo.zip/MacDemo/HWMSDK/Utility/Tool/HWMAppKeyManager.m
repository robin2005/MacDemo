//
//  HWMAppKeyManager.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/11/16.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMAppKeyManager.h"

@implementation HWMAppKeyManager

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    static HWMAppKeyManager *manager = nil;
    dispatch_once(&onceToken, ^{
        manager = [[HWMAppKeyManager alloc] init];
    });
    return manager;
}

- (NSString *)appId {
    if (_appId.length == 0) {
        _appId = @"fdb8e4699586458bbd10c834872dcc62";
        //_appId = @"56751232d42e49aba1ebded1577cc3be";
        //self.corpId = @"188503804";
    }
    return _appId;
}

- (NSString *)appKey {
    if (_appKey.length == 0) {
        _appKey = @"He35iFMBG6B88aMG";
        //_appKey = @"Tt39Q2a9GgE7HQ47";
    }
    return _appKey;
}

@end
