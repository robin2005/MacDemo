//
//  HWMLoginInputInfoModel.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/27.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWMLoginInputInfoModel : NSObject

/// 标题
@property (nonatomic, copy) NSString *title;
/// 内容
@property (nonatomic, copy) NSString *content;
/// 预留字
@property (nonatomic, copy) NSString *placeholder;

@end

NS_ASSUME_NONNULL_END
