//
//  HWMAddContactController.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/8/26.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMBaseViewController.h"
#import "HWMContactInfoModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^HWMAddContactHandler)(HWMContactInfoModel * _Nullable contactInfo);

@interface HWMAddContactController : HWMBaseViewController

@property (nonatomic, copy) HWMAddContactHandler addContactHandler;

@end

NS_ASSUME_NONNULL_END
