//
//  HWMWaterMarkController.m
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2021/10/19.
//  Copyright © 2021 Huawei Technologies Co. Ltd. All rights reserved.
//

#import "HWMWaterMarkController.h"
#import "HWMTextField.h"
#import <HWMUISDK/HWMUISDK.h>

@interface HWMWaterMarkController ()

@property (nonatomic, strong) HWMTextField *textField;
/// 背景
@property (nonatomic, strong) NSView *fieldBgView;

@property (nonatomic, strong) NSButton *setBtn;

@end

@implementation HWMWaterMarkController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
}

#pragma mark - UI
- (void)setupUI {

    [self.view addSubview:self.fieldBgView];
    [self.fieldBgView addSubview:self.textField];
    [self.view addSubview:self.setBtn];
    
    
    [self.fieldBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.view).offset(100);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(300);
    }];
    
    [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.fieldBgView);
        make.left.equalTo(self.fieldBgView).offset(5);
        make.right.equalTo(self.fieldBgView).offset(-5);
    }];
    
    [self.setBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.view);
        make.height.mas_equalTo(35);
        make.width.mas_equalTo(250);
    }];
}

- (void)setWaterMark {
    if (![HWMSdk hasInit]) {
        [HWMConsoleManager shareInstance].console = @"no init";
        return;
    }
    NSAttributedString *arr = [[NSAttributedString alloc] initWithString:self.textField.stringValue attributes:@{NSFontAttributeName:[NSFont systemFontOfSize:13], NSForegroundColorAttributeName:[NSColor redColor]}];
    [[HWMSdk getOpenApi] setWaterMark:arr];
}

- (HWMTextField *)textField {
    if (!_textField) {
        _textField = [[HWMTextField alloc] init];
        _textField.placeholderString = @"请输入水印";
    }
    return _textField;
}

- (NSView *)fieldBgView {
    if (!_fieldBgView) {
        _fieldBgView = [[NSView alloc] init];
        _fieldBgView.wantsLayer = YES;
        _fieldBgView.layer.backgroundColor = [NSColor whiteColor].CGColor;
        _fieldBgView.layer.borderColor = [NSColor colorWithRGB:0xEEEEEE].CGColor;
        _fieldBgView.layer.borderWidth = 1.0;
        _fieldBgView.layer.cornerRadius = 2.0;
        _fieldBgView.layer.masksToBounds = YES;
    }
    return _fieldBgView;
}

- (NSButton *)setBtn {
    if (!_setBtn) {
        _setBtn = [NSButton buttonWithTitle:@"设置水印" font:nil fontColor:[NSColor whiteColor] target:self action:@selector(setWaterMark)];
        _setBtn.layer.backgroundColor = [NSColor colorWithRGB:0x0D94FF].CGColor;
        _setBtn.layer.cornerRadius = 4.0;
        _setBtn.layer.masksToBounds = YES;
    }
    return _setBtn;
}

@end
