//
//  HWMConfTypeSelectCell.h
//  HWMUISDKNativeDemo
//
//  Created by guomeng on 2020/10/28.
//  Copyright © 2020 Huawei Technologies Co. Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@protocol HWMConfTypeSelectCellDelegate <NSObject>

- (void)selectedConfType:(NSInteger)confType;

@end

@interface HWMConfTypeSelectCell : NSTableCellView

+ (instancetype)initConfTypeSelectCell:(NSTableView *)tableView ower:(nullable id)ower;

/// 代理
@property (nonatomic, weak) id<HWMConfTypeSelectCellDelegate> delegate;
/// type
@property (nonatomic, assign) NSInteger confType;

@end

NS_ASSUME_NONNULL_END
